"""Export research figures from the completed, fixed Numerai pilot results.

Uses the saved per-date scores as the figure source and verifies their means
against metrics.csv before plotting. It does not recompute model predictions.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODELS = ["B0_small_main", "E1_medium_main", "E2_small_aux20", "E3_rank_ensemble"]
LABELS = {"B0_small_main": "B0 Small 60d", "E1_medium_main": "E1 Medium 60d",
          "E2_small_aux20": "E2 Small 20d", "E3_rank_ensemble": "E3 Rank ensemble"}
COLORS = {"B0_small_main": "#235b8e", "E1_medium_main": "#b56824",
          "E2_small_aux20": "#697528", "E3_rank_ensemble": "#a04e7c"}
LINESTYLES = {"B0_small_main": "-", "E1_medium_main": "--",
              "E2_small_aux20": ":", "E3_rank_ensemble": "-."}
SPLITS = ["tuning", "holdout"]


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_scores(output: Path) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    metrics = pd.read_csv(output / "metrics.csv")
    per_date = pd.read_csv(output / "per_date_metrics.csv", parse_dates=["date"])
    summary = metrics.loc[metrics.metric.eq("NCORR")].copy()
    if summary.duplicated(["split", "model"]).any():
        raise ValueError("NCORR summary has duplicate split/model records")
    if per_date.duplicated(["split", "model", "date"]).any():
        raise ValueError("Per-date source has duplicate split/model/date records")
    expected = {(split, model) for split in SPLITS for model in MODELS}
    actual = set(summary[["split", "model"]].itertuples(index=False, name=None))
    if actual != expected:
        raise ValueError(f"Unexpected experiment matrix: {actual}")
    if not np.isfinite(summary["mean"]).all() or not np.isfinite(per_date["NCORR"]).all():
        raise ValueError("NCORR must be available for every plotted date/model")
    scope = {}
    for split in SPLITS:
        pivot = per_date.loc[per_date.split.eq(split)].pivot(index="date", columns="model", values="NCORR")
        if set(pivot.columns) != set(MODELS) or pivot.isna().any().any():
            raise ValueError(f"{split}: model scoring dates differ")
        if pivot.empty or len(pivot) < 2:
            raise ValueError(f"{split}: insufficient reviewed dates")
        for model in MODELS:
            row = summary.loc[summary.split.eq(split) & summary.model.eq(model)].iloc[0]
            if int(row.n_scored_dates) != len(pivot):
                raise ValueError(f"{split}/{model}: date counts do not reconcile")
            if not np.isclose(pivot[model].mean(), row["mean"], rtol=1e-10, atol=1e-12):
                raise ValueError(f"{split}/{model}: mean differs from per-date source")
        scope[split] = {"first_date": pivot.index.min().strftime("%Y-%m-%d"),
                        "last_date": pivot.index.max().strftime("%Y-%m-%d"),
                        "n_dates": len(pivot),
                        "rows_per_date_min": int(per_date.loc[per_date.split.eq(split), "n_rows"].min()),
                        "rows_per_date_max": int(per_date.loc[per_date.split.eq(split), "n_rows"].max())}
    return summary, per_date, scope


def scope_text(split: str, scope: dict) -> str:
    values = scope[split]
    return (f"{split.capitalize()}: {values['first_date']} to {values['last_date']} "
            f"({values['n_dates']} dates)")


def style_axis(axis):
    axis.spines[["top", "right"]].set_visible(False)
    axis.spines[["left", "bottom"]].set_color("#777777")
    axis.tick_params(colors="#333333", labelsize=10)
    axis.grid(axis="y", color="#dddddd", linewidth=0.7)
    axis.set_axisbelow(True)


def plot_mean(summary: pd.DataFrame, scope: dict, destination: Path, training_rows: int | None = None):
    fig, ax = plt.subplots(figsize=(11.6, 6.2))
    fig.subplots_adjust(left=0.10, right=0.97, top=0.75, bottom=0.18)
    x = np.arange(len(MODELS))
    width = 0.34
    split_styles = {"tuning": {"color": "#235b8e", "hatch": ""},
                    "holdout": {"color": "#e1ad58", "hatch": "///"}}
    all_values = []
    for offset, split in zip([-width / 2, width / 2], SPLITS):
        values = [summary.loc[summary.split.eq(split) & summary.model.eq(model), "mean"].iloc[0]
                  for model in MODELS]
        all_values.extend(values)
        bars = ax.bar(x + offset, values, width, label=split.capitalize(),
                      edgecolor="#333333", linewidth=0.65, **split_styles[split])
        for bar, value in zip(bars, values):
            ax.annotate(f"{value:.4f}", (bar.get_x() + bar.get_width()/2, value),
                        textcoords="offset points", xytext=(0, 5 if value >= 0 else -5),
                        ha="center", va="bottom" if value >= 0 else "top", fontsize=10)
    ax.axhline(0, color="#555555", linewidth=0.9)
    low, high = min(0, min(all_values)), max(0, max(all_values))
    span = max(high - low, .005)
    ax.set_ylim(low - span*.13, high + span*.22)
    ax.set_xticks(x, [LABELS[model] for model in MODELS], fontsize=11)
    ax.set_ylabel("Mean per-date NCORR", fontsize=11)
    style_axis(ax)
    ax.legend(frameon=False, ncols=2, loc="upper left", fontsize=11)
    fig.suptitle("Numerai v6 pilot: mean NCORR", x=.10, y=.97, ha="left", fontsize=17)
    fig.text(.10, .875, scope_text("tuning", scope) + "\n" + scope_text("holdout", scope),
             fontsize=10.5, linespacing=1.5, color="#444444", va="top")
    training_note = (f"Models trained on {training_rows:,} fixed sampled rows."
                     if training_rows is not None else "Models use the same fixed training sample.")
    fig.text(.10, .055, "Equal weight per date. " + training_note + "\n"
             "Holdout scores compare frozen variants; model selection uses tuning only.",
             fontsize=10, color="#444444", linespacing=1.5)
    fig.savefig(destination, dpi=180, facecolor="white")
    plt.close(fig)


def plot_cumulative(per_date: pd.DataFrame, scope: dict, destination: Path):
    fig, axes = plt.subplots(2, 1, figsize=(11.6, 8.6), sharey=True)
    fig.subplots_adjust(left=.11, right=.97, top=.87, bottom=.12, hspace=.48)
    for split, ax in zip(SPLITS, axes):
        scores = per_date.loc[per_date.split.eq(split)].pivot(index="date", columns="model", values="NCORR").sort_index()
        for model in MODELS:
            # Duplicate the first timestamp to display the zero origin without
            # suggesting an unobserved score on an earlier market date.
            dates = pd.DatetimeIndex([scores.index[0]]).append(scores.index)
            cumulative = np.concatenate([[0.0], scores[model].cumsum().to_numpy()])
            ax.plot(dates, cumulative, label=LABELS[model], color=COLORS[model],
                    linestyle=LINESTYLES[model], linewidth=1.8)
        positions = np.unique(np.round(np.linspace(0, len(scores)-1, 5)).astype(int))
        ticks = scores.index[positions]
        ax.set_xticks(ticks)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
        ax.set_xlim(scores.index.min(), scores.index.max())
        ax.axhline(0, color="#555555", linewidth=.9)
        ax.set_title(scope_text(split, scope), loc="left", fontsize=11.5, pad=10)
        style_axis(ax)
    fig.suptitle("Numerai v6 pilot: cumulative NCORR", x=.11, y=.97, ha="left", fontsize=17)
    fig.legend(*axes[0].get_legend_handles_labels(), loc="upper left", bbox_to_anchor=(.102, .94),
               ncols=4, frameon=False, fontsize=10)
    fig.supylabel("Cumulative NCORR (additive score, not return)", x=.028, fontsize=11)
    fig.text(.11, .035, "Each panel starts at zero. The panels cover separate time periods and are not connected.\n"
             "Overlapping 60-day labels make successive dates dependent; no significance interval is implied.",
             fontsize=10, color="#444444", linespacing=1.5)
    fig.savefig(destination, dpi=180, facecolor="white")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results/pilot",
                        help="Directory containing metrics.csv and per_date_metrics.csv")
    args = parser.parse_args()
    output = args.output_dir.resolve()
    summary, per_date, scope = read_scores(output)
    run_path = output / "run.json"
    run_info = json.loads(run_path.read_text(encoding="utf-8")) if run_path.exists() else {}
    training_rows = run_info.get("train_sample_rows")
    figures = output / "figures"
    figures.mkdir(exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "axes.labelcolor": "#222222", "text.color": "#222222"})
    plot_mean(summary, scope, figures / "ncorr_comparison.png", training_rows)
    plot_cumulative(per_date, scope, figures / "cumulative_ncorr.png")
    sources = {"source_files": {name: sha256_file(output / name) for name in
                                 ["metrics.csv", "per_date_metrics.csv"]},
               "metric": "official neutral_correlation, equal weight per date",
               "scope": scope, "cumulative_definition": "Additive cumulative NCORR with initial zero; not investment returns",
               "mean_source_reconciled": True,
               "figures": ["ncorr_comparison.png", "cumulative_ncorr.png"]}
    if run_path.exists():
        sources["source_files"]["run.json"] = sha256_file(run_path)
    (figures / "figure_sources.json").write_text(json.dumps(sources, indent=2) + "\n", encoding="utf-8")
    print(f"Exported figures to {figures}")


if __name__ == "__main__":
    main()
