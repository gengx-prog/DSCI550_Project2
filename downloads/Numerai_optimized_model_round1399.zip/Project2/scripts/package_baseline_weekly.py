"""Build a lightweight ZIP from the current baseline working tree and weekly report.

The Git index is used only to enumerate files: modified and untracked non-ignored
files are read from disk. No repository state is changed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tempfile
import zipfile


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REPO = PROJECT_ROOT / ("github_submission" if (PROJECT_ROOT / "github_submission").is_dir() else "DSCI550_Project2")
DEFAULT_REPORT_DIR = PROJECT_ROOT / "output" / "baseline_weekly_20261107"
if not (PROJECT_ROOT / "github_submission").is_dir() and (PROJECT_ROOT / "report").is_dir():
    DEFAULT_REPORT_DIR = PROJECT_ROOT / "report"
PDF_NAME = "DSCI550_Baseline_Weekly_Update_20261107.pdf"
DEFAULT_PDF = PROJECT_ROOT / "output" / "pdf" / PDF_NAME
if not (PROJECT_ROOT / "github_submission").is_dir() and (PROJECT_ROOT / "report" / PDF_NAME).is_file():
    DEFAULT_PDF = PROJECT_ROOT / "report" / PDF_NAME
REPORT_EXTENSIONS = {".pdf", ".txt", ".md"}
REPORT_FILENAMES = {"report_sources.json"}
BLOCKED_PARTS = {
    ".git", ".venv", "venv", "__pycache__", "node_modules", "models",
    "raw", "processed", "secrets", ".secrets", "credentials",
}
BLOCKED_EXTENSIONS = {
    ".parquet", ".pyc", ".pyo", ".part", ".pem", ".key", ".p12", ".pfx",
    ".zip", ".sqlite", ".db",
}
BLOCKED_NAMES = {
    "auth.json", "credentials.json", "credentials.yaml", "credentials.yml",
    "secrets.json", "secrets.yaml", "secrets.yml", "id_rsa", "id_ed25519",
}


def rejected(relative: PurePosixPath) -> bool:
    parts = {part.casefold() for part in relative.parts}
    name = relative.name.casefold()
    return (
        bool(parts & BLOCKED_PARTS)
        or name.startswith(".env")
        or name in BLOCKED_NAMES
        or relative.suffix.casefold() in BLOCKED_EXTENSIONS
        or ".." in relative.parts
        or relative.is_absolute()
    )


def checked_file(root: Path, relative: PurePosixPath) -> Path:
    """Reject symlinks (including directory links) and paths outside the root."""
    current = root
    for part in relative.parts:
        current = current / part
        if current.is_symlink() or current.is_junction():
            raise ValueError(f"Links are not permitted: {relative}")
    candidate = root.joinpath(*relative.parts).resolve(strict=True)
    if not candidate.is_relative_to(root) or not candidate.is_file():
        raise ValueError(f"Not a regular file within its source directory: {relative}")
    return candidate


def collect(repo: Path, report_dir: Path, pdf: Path) -> tuple[dict[str, bytes], list[str]]:
    listing = subprocess.run(
        ["git", "-C", str(repo), "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
        check=True, capture_output=True,
    ).stdout
    payloads: dict[str, bytes] = {}
    excluded: list[str] = []
    for raw_name in sorted(set(listing.split(b"\0")) - {b""}):
        relative = PurePosixPath(os.fsdecode(raw_name))
        if rejected(relative):
            excluded.append(relative.as_posix())
            continue
        source = checked_file(repo, relative)
        payloads[f"DSCI550_Project2/{relative.as_posix()}"] = source.read_bytes()

    if report_dir.exists():
        for source in sorted(report_dir.iterdir(), key=lambda item: item.name.casefold()):
            relative = PurePosixPath(source.name)
            if (source.suffix.casefold() not in REPORT_EXTENSIONS
                    and source.name not in REPORT_FILENAMES) or rejected(relative):
                continue
            source = checked_file(report_dir, relative)
            payloads[f"report/{relative.as_posix()}"] = source.read_bytes()
    if pdf.exists():
        source = checked_file(pdf.parent, PurePosixPath(pdf.name))
        archive_name = f"report/{pdf.name}"
        if archive_name in payloads and payloads[archive_name] != source.read_bytes():
            raise ValueError("Two different PDFs have the same archive name")
        payloads[archive_name] = source.read_bytes()
    script_location = Path(__file__).absolute()
    script = checked_file(script_location.parent, PurePosixPath(script_location.name))
    payloads["tools/package_baseline_weekly.py"] = script.read_bytes()
    return dict(sorted(payloads.items())), excluded


def archive_bytes(payloads: dict[str, bytes]) -> dict[str, bytes]:
    manifest = {
        "schema_version": 1,
        "description": "Baseline weekly submission file inventory; hashes describe packaged bytes.",
        "repository_selection": "Current working tree from git ls-files --cached --others --exclude-standard, with artifact and secret exclusions.",
        "file_count": len(payloads),
        "total_uncompressed_bytes": sum(map(len, payloads.values())),
        "files": [
            {"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for name, data in payloads.items()
        ],
    }
    return {
        **payloads,
        "SUBMISSION_MANIFEST.json": (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode("utf-8"),
    }


def build_zip(destination: Path, payloads: dict[str, bytes]) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=".baseline-package-", suffix=".tmp", dir=destination.parent)
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, data in sorted(archive_bytes(payloads).items()):
                entry = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 0, 0, 0))
                entry.create_system = 3
                entry.external_attr = 0o100644 << 16
                entry.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(entry, data, compresslevel=9)
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError("ZIP integrity validation failed")
            manifest = json.loads(archive.read("SUBMISSION_MANIFEST.json"))
            for item in manifest["files"]:
                data = archive.read(item["path"])
                if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
                    raise ValueError(f"ZIP manifest mismatch: {item['path']}")
        # A hard link provides atomic creation without replacing an existing ZIP.
        os.link(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=DEFAULT_REPO)
    parser.add_argument("--report-dir", type=Path, default=DEFAULT_REPORT_DIR)
    parser.add_argument("--pdf", type=Path, default=DEFAULT_PDF)
    parser.add_argument("--output", type=Path, help="ZIP path; defaults to report-dir/DSCI550_Baseline_Weekly_20261107.zip")
    parser.add_argument("--dry-run", action="store_true", help="List selected contents and sizes without writing a ZIP")
    args = parser.parse_args()
    if args.repo.is_symlink() or args.repo.is_junction() or args.report_dir.is_symlink() or args.report_dir.is_junction():
        raise ValueError("Source directories must not be links")
    repo = args.repo.resolve(strict=True)
    report_dir = args.report_dir.resolve()
    pdf = args.pdf.absolute()
    destination = (args.output or report_dir / "DSCI550_Baseline_Weekly_20261107.zip").resolve()
    if repo.is_symlink() or not repo.is_dir():
        raise ValueError("Repository must be an existing regular directory")
    if not args.dry_run and destination.exists():
        raise FileExistsError("Output already exists; choose a fresh ZIP path")

    payloads, excluded = collect(repo, report_dir, pdf)
    repo_count = sum(name.startswith("DSCI550_Project2/") for name in payloads)
    report_names = [name for name in payloads if name.startswith("report/")]
    summary = {
        "dry_run": args.dry_run,
        "repository_files": repo_count,
        "report_files": report_names,
        "payload_files": len(payloads),
        "payload_bytes": sum(map(len, payloads.values())),
        "explicitly_excluded_git_candidates": excluded,
        "canonical_pdf_available": pdf.is_file(),
    }
    if not args.dry_run:
        if not report_names:
            raise ValueError("No report files found; refusing to create an incomplete weekly package")
        if not pdf.is_file() or not pdf.stat().st_size:
            raise ValueError("The canonical PDF report is missing or empty")
        build_zip(destination, payloads)
        summary.update({"zip_name": destination.name, "zip_bytes": destination.stat().st_size,
                        "zip_sha256": hashlib.sha256(destination.read_bytes()).hexdigest()})
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
