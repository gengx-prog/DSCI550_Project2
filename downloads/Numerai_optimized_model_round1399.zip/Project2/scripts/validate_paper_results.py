"""Independently audit a completed paper-informed Numerai optimization run.

This script refuses to write an audit while the experiment status is incomplete.
It recomputes all saved aggregate scores and selection arithmetic, reconstructs
the chronological samples, checks serialized feature schemas, and independently
rescores one full date from each evaluation phase.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from scipy import linalg, stats
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
KEYS = ["numerai_ticker", "date"]
TARGET = "target_jupiter_60"
MODELS = ["P0_small_200k", "P1_medium_200k", "P2_medium_600k", "P3_recency_600k",
          "P4_xgboost", "P5_catboost", "P6_seed_ensemble", "P7_heterogeneous"]
TOL = 1e-10


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sample_hash(frame: pd.DataFrame) -> str:
    return hashlib.sha256(frame[KEYS].to_csv(index=False, date_format="%Y-%m-%d").encode("utf-8")).hexdigest()


def require(condition, message: str):
    if not condition:
        raise AssertionError(message)


def close(actual, expected, message: str):
    require(np.isclose(actual, expected, atol=TOL, rtol=0, equal_nan=True),
            f"{message}: recorded={actual}, independently computed={expected}")


def independently_summarize(values: np.ndarray) -> dict:
    """Do not import the implementation under audit."""
    values = np.asarray(values, dtype=float)
    require(len(values) > 0 and np.isfinite(values).all(), "Invalid score array")
    std = float(np.sqrt(np.mean((values - values.mean()) ** 2)))
    total = np.r_[0.0, np.cumsum(values)]
    max_to_date = np.maximum.accumulate(total)
    return {"mean": float(np.sum(values) / len(values)), "std_ddof0": std,
            "sharpe": float(values.mean() / std) if std else np.nan,
            "worst_date_score": float(min(values)),
            "max_drawdown": float(max(max_to_date - total)),
            "positive_fraction": float(np.count_nonzero(values > 0) / len(values))}


def independent_correlations(predictions: np.ndarray, targets: np.ndarray, neutralizers: np.ndarray):
    """Independent formula preserving the scorer's source-operation precision.

    The official scorer centers the original target Series, and computes its
    signed power, before pandas Pearson correlation converts values to float64.
    Numerai targets are float32: promoting them before these transformations
    changes quantization by about 1e-8 and can change correlations by about 1e-9.
    Preserve the native target transformations, then use float64 Pearson sums.
    """
    targets = np.asarray(targets)
    gaussian = stats.norm.ppf((stats.rankdata(predictions, method="average", axis=0) - .5) / len(targets))
    centered_target_native = targets - targets.mean()
    centered_target = centered_target_native.astype(float)
    centered_target -= centered_target.mean()
    design = np.column_stack([neutralizers.astype(float), np.ones(len(targets))])
    coefficients, _, _, _ = linalg.lstsq(design, gaussian, cond=1e-6, lapack_driver="gelsd")
    residual = gaussian - design @ coefficients
    residual -= residual.mean(axis=0)
    ncorr = np.sum(residual * centered_target[:, None], axis=0) / np.sqrt(
        np.sum(residual ** 2, axis=0) * np.sum(centered_target ** 2))
    pred_power = np.sign(gaussian) * np.abs(gaussian) ** 1.5
    target_power = (np.sign(centered_target_native) * np.abs(centered_target_native) ** 1.5).astype(float)
    pred_power -= pred_power.mean(axis=0)
    target_power -= target_power.mean()
    corr = np.sum(pred_power * target_power[:, None], axis=0) / np.sqrt(
        np.sum(pred_power ** 2, axis=0) * np.sum(target_power ** 2))
    return corr, ncorr


def verify_serialized_model(record: dict, expected_features: list[str]) -> dict:
    path = Path(record["model_file"])
    require(path.is_file(), f"Missing serialized model: {path}")
    require(record["feature_names"] == expected_features, f"Recorded feature schema differs: {record['model']}")
    family = record["family"]
    if family == "lightgbm":
        import lightgbm as lgb
        model = lgb.Booster(model_file=str(path))
        names, trees = model.feature_name(), model.num_trees()
    elif family == "xgboost":
        import xgboost as xgb
        model = xgb.Booster()
        model.load_model(path)
        names, trees = model.feature_names, model.num_boosted_rounds()
    elif family == "catboost":
        from catboost import CatBoostRegressor
        model = CatBoostRegressor()
        model.load_model(str(path))
        names, trees = model.feature_names_, model.tree_count_
    else:
        raise ValueError(f"Unexpected serialized family: {family}")
    require(list(names) == expected_features, f"Actual serialized feature schema differs: {record['model']}")
    require(trees == 300, f"Unexpected model tree count: {record['model']}={trees}")
    require(all(name.startswith("feature_") and name != "feature_country" for name in names),
            "A key/date/target/text column entered a serialized model")
    require(record.get("evaluation_labels_used_in_fit") is False, "Training record permits evaluation-label use")
    return {"model": record["model"], "family": family, "trees": int(trees), "n_features": len(names)}


def rescore_date(root: Path, output: Path, fold: dict, scores: pd.DataFrame) -> dict:
    from numerai_tools.scoring import neutral_correlation, numerai_corr

    date = pd.Timestamp(fold["eval_start"])
    path = output / "folds" / fold["id"] / "predictions.parquet"
    predictions = pd.read_parquet(path, filters=[("date", "==", date)])
    predictions["date"] = pd.to_datetime(predictions["date"])
    predictions = predictions.sort_values("numerai_ticker").reset_index(drop=True)
    require(len(predictions) > 0, "Sampled scoring date has no predictions")
    neutralizer_path = root / "data/raw/v6.0/validation_neutralizer.parquet"
    columns = [f for f in pq.read_schema(neutralizer_path).names if f.startswith("neutralizer_column_")]
    neutralizers = pd.read_parquet(neutralizer_path, columns=KEYS + columns,
                                  filters=[("date", "==", date.strftime("%Y-%m-%d"))])
    neutralizers["date"] = pd.to_datetime(neutralizers.date)
    aligned = predictions[KEYS].merge(neutralizers, on=KEYS, how="left", sort=False, validate="one_to_one")
    require(len(aligned) == len(predictions) and not aligned[columns].isna().any().any(),
            "Incomplete independently aligned neutralizer coverage")
    raw_targets = pd.read_parquet(root / "data/raw/v6.0/validation.parquet", columns=KEYS + [TARGET, "data_type"],
                                  filters=[("date", "==", date.strftime("%Y-%m-%d"))])
    raw_targets["date"] = pd.to_datetime(raw_targets.date)
    target_match = predictions[KEYS + [TARGET]].merge(raw_targets, on=KEYS, how="left", validate="one_to_one", suffixes=("_saved", "_raw"))
    require(target_match.data_type.eq("validation").all(), "Sampled rows include a non-validation data type")
    require(np.array_equal(target_match[TARGET + "_saved"], target_match[TARGET + "_raw"]),
            "Saved scoring targets differ from original raw labels")
    y = predictions[TARGET].to_numpy()  # Preserve native target centering/power precision.
    corr, ncorr = independent_correlations(predictions[MODELS].to_numpy(dtype=float), y,
                                          aligned[columns].to_numpy(dtype=float))
    official_corr = numerai_corr(predictions[MODELS], predictions[TARGET], max_filtered_index_ratio=0)
    official_ncorr = neutral_correlation(predictions[MODELS], aligned[columns], predictions[TARGET], max_filtered_index_ratio=0)
    recorded = scores.loc[scores.fold.eq(fold["id"]) & scores.date.eq(date)].set_index("model").loc[MODELS]
    require(len(recorded) == len(MODELS) and recorded.n_rows.eq(len(predictions)).all(), "Sampled date count mismatch")
    errors = {
        "independent_CORR_max_abs_error": float(np.max(np.abs(corr - recorded.CORR.to_numpy()))),
        "independent_NCORR_max_abs_error": float(np.max(np.abs(ncorr - recorded.NCORR.to_numpy()))),
        "official_CORR_max_abs_error": float(np.max(np.abs(official_corr.loc[MODELS].to_numpy() - recorded.CORR.to_numpy()))),
        "official_NCORR_max_abs_error": float(np.max(np.abs(official_ncorr.loc[MODELS].to_numpy() - recorded.NCORR.to_numpy()))),
    }
    require(all(v < TOL for v in errors.values()), f"Sampled-date score discrepancies: {errors}")
    return {"phase": fold["phase"], "fold": fold["id"], "date": str(date.date()),
            "rows": len(predictions), "models": len(MODELS), "neutralizer_columns": len(columns),
            "missing_neutralizer_rows": 0, "target_matches_raw": True,
            "target_source_dtype": str(y.dtype),
            "independent_operation_precision": "Native target dtype for centering and signed power; float64 for projection and Pearson, matching official operation order",
            **errors}


def audit(root: Path, output: Path) -> dict:
    root, output = root.resolve(), output.resolve()
    run = read_json(output / "run.json")
    require(run["status"] == "complete", "Refusing to audit or write results for an incomplete experiment")
    plan_document = read_json(output / "plan.json")
    plan, selection = plan_document["folds"], read_json(output / "selection.json")
    metrics = pd.read_csv(output / "metrics.csv")
    scores = pd.read_csv(output / "per_date_metrics.csv", parse_dates=["date"])
    require(set(scores.phase.unique()) == {"cv", "reused_development"}, "Incorrect historical phase labels")
    require(set(scores.model.unique()) == set(MODELS), "Candidate IDs do not match the frozen matrix")
    require(not scores.duplicated(["phase", "fold", "date", "model"]).any(), "Duplicate per-date scores")
    require(np.isfinite(scores[["CORR", "NCORR", "n_rows"]].to_numpy()).all(), "Nonfinite recorded scores")
    require(not metrics.duplicated(["phase", "model", "metric"]).any(), "Duplicate summary records")
    require(len(metrics) == 2 * len(MODELS) * 2, "Incomplete summary matrix")
    summary_count = 0
    for (phase, model), group in scores.groupby(["phase", "model"], sort=True):
        group = group.sort_values("date")
        for metric in ["CORR", "NCORR"]:
            row = metrics.loc[metrics.phase.eq(phase) & metrics.model.eq(model) & metrics.metric.eq(metric)]
            require(len(row) == 1, "Missing independent summary comparison")
            row = row.iloc[0]
            expected = independently_summarize(group[metric].to_numpy())
            for name, value in expected.items():
                close(row[name], value, f"{phase}/{model}/{metric}/{name}")
            fold_means = group.groupby("fold")[metric].mean().to_numpy()
            close(row.fold_mean_std_ddof0, float(np.std(fold_means)), "Fold mean dispersion")
            close(row.worst_fold_mean, float(min(fold_means)), "Worst fold mean")
            require(row.n_scored_dates == len(group) == row.n_dates and row.n_folds == len(fold_means),
                    "Summary counts do not reconcile")
            summary_count += 1
    print(f"Independently verified {summary_count} summary records", flush=True)
    cv = scores.loc[scores.phase.eq("cv")]
    require(cv.fold.nunique() == 4, "Not all four CV folds are present")
    independent_selection = {}
    for model in MODELS:
        group = cv.loc[cv.model.eq(model)]
        mean = float(group.NCORR.mean())
        fold_means = group.groupby("fold").NCORR.mean()
        std = float(np.std(fold_means.to_numpy()))
        score = mean - .5 * std
        independent_selection[model] = score
        saved = selection["candidates"][model]
        close(saved["mean_NCORR_equal_date"], mean, "Selection equal-date mean")
        close(saved["fold_mean_std_ddof0"], std, "Selection fold standard deviation")
        close(saved["selection_score"], score, "Selection criterion")
        for key, value in fold_means.items():
            close(saved["fold_mean_NCORR"][str(key)], value, "Selection fold mean")
    winner = sorted(MODELS, key=lambda x: (-independent_selection[x], x))[0]
    require(selection["selected_model"] == winner == run["selected_model"], "Frozen winner differs from independent CV ranking")
    require(selection["selection_phase"] == "cv" and selection["development_used_for_selection"] is False,
            "Selection phase was not restricted to CV")
    require(selection["historical_benchmark_already_observed_in_prior_pilot"] is True,
            "Observed-benchmark disclosure missing")
    require(selection["reused_development_scored_before_this_run_selection"] is False,
            "Development scored before current-run selection")
    metadata = read_json(root / "data/raw/v6.0/features.json")
    feature_sets = {name: [x for x in metadata["feature_sets"][name] if x != "feature_country"]
                    for name in ["small", "medium"]}
    provenance = plan_document["source_provenance"]
    cache = root / provenance["cache_path"]
    require(sha256_file(cache) == provenance["cache_sha256"], "Research-pool content hash mismatch")
    pool_keys = pd.read_parquet(cache, columns=KEYS)
    pool_keys["date"] = pd.to_datetime(pool_keys.date)
    pool_keys.sort_values(["date", "numerai_ticker"], kind="stable", inplace=True)
    pool_keys.reset_index(drop=True, inplace=True)
    require(not pool_keys.duplicated(KEYS).any() and not pool_keys.isna().any().any(), "Invalid research-pool keys")
    frozen = pd.Timestamp(selection["frozen_at_utc"])
    require(pd.Timestamp(run["started_utc"]) <= frozen <= pd.Timestamp(run["completed_utc"]),
            "Selection freeze timestamp is outside run timestamps")
    fold_reports, all_dev_mtimes = [], []
    for fold in plan:
        fold_id = fold["id"]
        directory = output / "folds" / fold_id
        training_file = read_json(directory / "training.json")
        sample_manifest = read_json(directory / "models/training_manifest.json")
        records = {r["model"]: r for r in training_file["models"]}
        require(set(records) == set(MODELS), f"Missing training records for {fold_id}")
        require(training_file["fold"] == fold, "Frozen fold definition changed")
        require(fold["embargo_weekdays"] == 65, "Unexpected embargo policy")
        start, end = pd.Timestamp(fold["eval_start"]), pd.Timestamp(fold["eval_end"])
        cutoff = pd.Timestamp(fold["train_cutoff_exclusive"])
        require(cutoff == start - pd.offsets.BDay(65), "Declared fold cutoff is inconsistent")
        eligible = pool_keys.loc[pool_keys.date < cutoff]
        require(eligible.date.max() + pd.offsets.BDay(65) < start, "Training labels overlap scoring start")
        sample = eligible.sample(n=min(int(run["max_train_rows"]), len(eligible)), random_state=int(run["seed"])).reset_index(drop=True)
        nested = sample.iloc[:min(200000, len(sample))]
        large_sha, small_sha = sample_hash(sample), sample_hash(nested)
        require(sample_manifest["large_sample_keys_sha256"] == large_sha and sample_manifest["nested_sample_keys_sha256"] == small_sha,
                "Independently reconstructed sample hashes differ")
        require(sample_manifest["large_sample_rows"] == len(sample) and sample_manifest["nested_sample_rows"] == len(nested),
                "Sample row counts differ")
        serialized = []
        for name, record in records.items():
            expected_hash = small_sha if name in MODELS[:2] else large_sha
            expected_rows = len(nested) if name in MODELS[:2] else len(sample)
            require(record["sample_keys_sha256"] == expected_hash and record["training_rows"] == expected_rows,
                    f"Candidate sample does not match controlled sample: {fold_id}/{name}")
            require(record["target"] == TARGET and record["evaluation_labels_used_in_fit"] is False,
                    "Wrong target or evaluation-label fitting declaration")
            if record["family"] != "rank_ensemble":
                expected_features = feature_sets["small" if name == "P0_small_200k" else "medium"]
                serialized.append(verify_serialized_model(record, expected_features))
            if name == "P3_recency_600k":
                config = record["weight_config"]
                require(pd.Timestamp(config["reference_date"]) == eligible.date.max(), "Recency reference did not use full eligible history")
                close(config["normalized_mean"], 1, "Recency weights normalization")
                require(config["min"] > 0 and config["half_life_years"] == 4, "Invalid recency-weight configuration")
        seed_records = records["P6_seed_ensemble"]["member_training_records"]
        require([r["seed"] for r in seed_records] == [run["seed"], 19, 43], "Seed ensemble members changed")
        require(all(r["sample_keys_sha256"] == large_sha for r in seed_records), "Seed ensemble samples differ")
        for record in seed_records[1:]:
            serialized.append(verify_serialized_model(record, feature_sets["medium"]))
        for name in ["P6_seed_ensemble", "P7_heterogeneous"]:
            close(sum(records[name]["params"]["weights"]), 1, "Ensemble weights")
        predictions = pd.read_parquet(directory / "predictions.parquet")
        predictions["date"] = pd.to_datetime(predictions.date)
        require(not predictions[KEYS + [TARGET] + MODELS].isna().any().any(), "Missing prediction key/target/value")
        require(not predictions.duplicated(KEYS).any(), "Duplicate prediction keys")
        require(np.isfinite(predictions[MODELS].to_numpy()).all(), "Nonfinite model prediction")
        require(predictions.date.min() == start and predictions.date.max() == end, "Scored date extent differs from plan")
        require(predictions.date.nunique() == fold["n_eval_dates"], "Scored date count differs from plan")
        counts = predictions.groupby("date").size()
        fold_scores = scores.loc[scores.fold.eq(fold_id)]
        require(set(fold_scores.model.unique()) == set(MODELS) and fold_scores.phase.eq(fold["phase"]).all(),
                "Fold phase or candidate matrix mismatch")
        for name in MODELS:
            rows = fold_scores.loc[fold_scores.model.eq(name)].set_index("date").sort_index()
            require(rows.index.equals(counts.index) and np.array_equal(rows.n_rows.to_numpy(), counts.to_numpy()),
                    "Candidate scores use different populations or dates")
        local_scores = pd.read_csv(directory / "per_date_metrics.csv", parse_dates=["date"])
        local = local_scores.sort_values(["date", "model"]).reset_index(drop=True)
        global_part = fold_scores.sort_values(["date", "model"]).reset_index(drop=True)
        pd.testing.assert_frame_equal(local, global_part, check_exact=False, atol=TOL, rtol=0)
        if fold["phase"] == "reused_development":
            model_files = list((directory / "models").glob("*.txt")) + list((directory / "models").glob("*.json")) + list((directory / "models").glob("*.cbm"))
            mtimes = [datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc) for path in model_files]
            require(mtimes and min(pd.Timestamp(x) for x in mtimes) > frozen, "Development model artifact persisted before selection freeze")
            all_dev_mtimes.extend(mtimes)
        fold_reports.append({"fold": fold_id, "phase": fold["phase"], "training_cutoff_exclusive": str(cutoff.date()),
                             "full_eligible_training_max": str(eligible.date.max().date()), "evaluation_start": str(start.date()),
                             "large_sample_rows": len(sample), "nested_sample_rows": len(nested),
                             "sample_hashes_rebuilt": True, "serialized_models_checked": serialized,
                             "prediction_rows": len(predictions), "scored_dates": len(counts),
                             "same_candidate_populations": True})
        print(f"Audited {fold_id}: samples, schema, embargo, and scoring populations", flush=True)
    require(run["completed_folds"] == [f["id"] for f in plan], "Completed fold list differs from frozen plan")
    rescored = [rescore_date(root, output, next(f for f in plan if f["phase"] == phase), scores)
                for phase in ["cv", "reused_development"]]
    code_hashes = {}
    for name, expected in run["code_sha256"].items():
        actual = sha256_file(root / "scripts" / name)
        require(actual == expected, f"Experiment source changed during or after run: {name}")
        code_hashes[name] = actual
    require(sha256_file(root / "Numerai_20_CCF_AB_Papers.zip") == run["archive_sha256"], "Paper archive hash changed")
    for relative, expected in provenance["source_sha256"].items():
        require(sha256_file(root / relative) == expected, f"Research source changed: {relative}")
    paired = read_json(output / "paired_comparison.json")
    require(paired["phase"] == "reused_development" and paired["selected_model"] == winner,
            "Paired historical comparison uses incorrect phase/winner")
    development = scores.loc[scores.phase.eq("reused_development")]
    pivot = development.pivot(index=["date", "fold"], columns="model", values="NCORR").sort_index()
    require(not pivot.isna().any().any(), "Unpaired development scoring populations")
    delta = (pivot[winner] - pivot[paired["baseline_model"]]).to_numpy()
    close(paired["observed_mean_NCORR_delta"], float(delta.mean()), "Paired mean score difference")
    require(paired["n_dates"] == len(delta), "Bootstrap paired date count mismatch")
    rng = np.random.default_rng(paired["seed"])
    for length in [13, 26]:
        n_blocks = math.ceil(len(delta) / length)
        starts = rng.integers(0, len(delta), size=(paired["replicates"], n_blocks))
        replicated_means = np.array([
            np.mean(delta[[(int(s) + j) % len(delta) for s in row for j in range(length)][:len(delta)]])
            for row in starts])
        lo, hi = np.percentile(replicated_means, [2.5, 97.5])
        close(paired["block_bootstrap"][str(length)]["ci95_low"], lo, "Bootstrap lower percentile")
        close(paired["block_bootstrap"][str(length)]["ci95_high"], hi, "Bootstrap upper percentile")
    return {
        "status": "passed", "audited_at_utc": datetime.now(timezone.utc).isoformat(),
        "run_status": run["status"], "absolute_score_tolerance": TOL,
        "all_summary_records_independently_recomputed": summary_count,
        "selection_independent_winner": winner, "selection_criterion_values": independent_selection,
        "selection_frozen_at_utc": selection["frozen_at_utc"],
        "earliest_development_model_artifact_mtime_utc": min(all_dev_mtimes).isoformat(),
        "freeze_order_scope": "Verified runner source loops over CV before reused development, writes selection after CV, and model artifact mtimes occur after freeze. Artifact timestamps do not independently prove training-start time.",
        "folds": fold_reports, "sampled_full_date_rescores": rescored,
        "rescore_scope": "Two complete dates, one per phase, eight candidates each; this is not an independent rescore of every date.",
        "bootstrap_percentiles_independently_reconstructed": [13, 26],
        "code_sha256_verified": code_hashes, "archive_sha256_verified": True,
        "research_source_sha256_verified": True,
        "historical_interpretation": "2023+ was observed previously. The new result and paired bootstrap remain reused development evidence, not a confirmatory untouched holdout or live result.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", "--output-dir", dest="output", type=Path, default=ROOT / "results/paper_optimization")
    parser.add_argument("--n-jobs", type=int, default=4)
    args = parser.parse_args()
    # Preserve live experiment artifacts: do not even write a failure record
    # when the experiment has not completed.
    run = read_json(args.output.resolve() / "run.json")
    if run.get("status") != "complete":
        raise RuntimeError("Experiment is incomplete; audit has not written any result")
    with threadpool_limits(limits=args.n_jobs):
        report = audit(args.root, args.output)
    destination = args.output.resolve() / "validation.json"
    destination.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"Independent audit passed: {destination}")


if __name__ == "__main__":
    main()
