"""Consolidate the supplied twenty-paper reviews with a verifiable archive manifest.

No PDF is reinterpreted here: the three reviewed JSON files supply method notes
and physical PDF page evidence. Archive/index metadata supply canonical titles,
source URLs and file identities. Implemented scope describes this specific round.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REVIEW_FILES = ["tree_review.json", "temporal_review.json", "robustness_review.json"]

# Application or an inspired evaluation control is deliberately distinguished
# from reproducing a paper's named full algorithm and published experiments.
IMPLEMENTED_SCOPE = {
    1: ("application", "Apply the LightGBM library; defer GOSS-specific and EFB-specific ablations.",
        "GBDT controls P0/P1/P2, fixed recency/date-weight control P3, and P6 tree members. No GOSS or EFB speedup claim."),
    2: ("application", "Apply a fixed modern library configuration rather than reproduce the 2016 systems benchmark.",
        "P4 uses CPU histogram XGBoost; P7 includes its within-date ranks. Same main target and large training sample as P2."),
    3: ("application", "Apply CatBoost Plain; defer Ordered boosting and categorical-feature experiments.",
        "P5 uses explicitly configured Plain CPU CatBoost with numeric features; P7 includes its ranks. Neither ordered boosting nor categorical target statistics is evaluated."),
    4: ("deferred", "Defer neural models this round; preserve the paper's matched-comparison principle.",
        "No FT-Transformer, ResNet or neural MLP is trained in this round."),
    5: ("deferred", "Defer TabNet and masked-feature pretraining.",
        "No TabNet architecture, sparse attention mask, or pretraining is implemented."),
    6: ("deferred", "Defer learned numerical embeddings and ordinal neural representation ablations.",
        "No PLE, periodic embedding or neural backbone is trained."),
    7: ("deferred", "Defer DeepGBM tree-to-network distillation and CatNN.",
        "No leaf-structure distillation, GBDT2NN or online neural updater is implemented."),
    8: ("deferred", "Defer Trompt.",
        "No learned prompts, column embeddings or Trompt cells are implemented."),
    9: ("deferred", "Defer pretrained tabular foundation models.",
        "No TabICLv2 checkpoint, in-context prediction or synthetic pretraining is used."),
    10: ("inspiration", "Use delayed-feedback discipline; defer the TRA architecture.",
        "Enforce target-maturity gaps before every temporal fit. No router, prediction-error memory or optimal transport is implemented."),
    11: ("inspiration", "Use lag-aware annual refitting and a separate fixed recency control; defer DoubleAdapt.",
        "Chronological annual refits and P3's four-year half-life weights test model aging. No learned data/label adapters or bilevel meta-learning is implemented."),
    12: ("inspiration", "Use temporal-environment evaluation; defer AdaRNN.",
        "Report chronological fold/year behavior. No TDC partition optimizer, RNN or hidden-state distribution matching is implemented."),
    13: ("deferred", "Defer StockMixer until an aligned stock-history tensor and masking protocol exist.",
        "No indicator/time/stock mixing network or raw-price forecasting task is implemented."),
    14: ("deferred", "Defer MASTER because its history/market-status inputs are not present in the current matrix.",
        "No market-guided gating or intra/inter-stock attention is implemented."),
    15: ("deferred", "Defer the temporal relational graph model.",
        "Per-date ranking evaluation is retained, but no stock-relation graph, LSTM or temporal graph convolution is implemented."),
    16: ("deferred", "Defer adversarial attentive-LSTM training.",
        "No sequential neural model, latent adversarial perturbation or adversarial objective is implemented."),
    17: ("inspiration", "Apply independent-member ensemble diversity; defer probabilistic Deep Ensembles.",
        "P6 averages fixed ranks of three LightGBM seeds; P7 averages LightGBM/XGBoost/CatBoost ranks. This is a tree ensemble, not calibrated predictive uncertainty."),
    18: ("inspiration", "Use a fixed temporal-stability selection criterion; defer the V-REx training objective.",
        "Select by equal-date CV mean NCORR minus 0.5 times population standard deviation of fold means. No risk-variance training penalty or invariance claim."),
    19: ("deferred", "Defer original DGBR global feature balancing and autoencoder optimization.",
        "Average and temporal stability are reported. P3's inverse-date-count weights do not implement DGBR or causal feature balancing."),
    20: ("deferred", "Defer validation-gradient meta-reweighting.",
        "P3 uses fixed exponential recency weights. It does not learn weights through validation meta-gradients and is not Ren et al.'s algorithm.")
}


def sha256_stream(stream) -> str:
    digest = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(block)
    return digest.hexdigest()


def sha256_file(path: Path) -> str:
    with path.open("rb") as stream:
        return sha256_stream(stream)


def safe_archive_members(archive: zipfile.ZipFile, destination: Path):
    """Validate every resolved path before writing any archive member on Windows."""
    root = destination.resolve()
    if sum(info.file_size for info in archive.infolist()) > 200 * 1024 * 1024:
        raise ValueError("Archive expands beyond the 200 MiB paper-package limit")
    checked = []
    seen = set()
    for info in archive.infolist():
        name = info.filename
        pure = PurePosixPath(name)
        if (pure.is_absolute() or ".." in pure.parts or "\\" in name or ":" in name
                or "\x00" in name or not pure.parts
                or pure.parts[0] != "Numerai_20_Algorithm_Papers"):
            raise ValueError(f"Unsafe or out-of-scope archive path: {name!r}")
        if stat.S_ISLNK(info.external_attr >> 16):
            raise ValueError(f"Archive symlink is not allowed: {name}")
        target = (root / Path(*pure.parts)).resolve()
        if not target.is_relative_to(root) or target == root:
            raise ValueError(f"Archive path escapes intended destination: {name}")
        identity = str(target).casefold()
        if identity in seen:
            raise ValueError(f"Repeated archive destination: {name}")
        seen.add(identity)
        checked.append((info, target))
    return checked


def verify_archive(archive_path: Path, papers_dir: Path, extract_if_needed: bool) -> dict:
    papers_dir.mkdir(parents=True, exist_ok=True)
    files = []
    with zipfile.ZipFile(archive_path) as archive:
        checked = safe_archive_members(archive, papers_dir)
        missing = [info.filename for info, target in checked if not info.is_dir() and not target.is_file()]
        if missing and not extract_if_needed:
            raise FileNotFoundError(f"Extracted source files missing; rerun with --extract-if-needed: {missing}")
        for info, target in checked:
            if info.is_dir():
                if extract_if_needed:
                    target.mkdir(parents=True, exist_ok=True)
                continue
            if not target.is_file():
                target.parent.mkdir(parents=True, exist_ok=True)
                # Only validated, missing files are written; existing references
                # are never silently replaced with a different archive revision.
                with archive.open(info) as source, target.open("xb") as dest:
                    shutil.copyfileobj(source, dest, length=1024 * 1024)
            with archive.open(info) as source:
                archive_member_hash = sha256_stream(source)
            local_hash = sha256_file(target)
            if target.stat().st_size != info.file_size or local_hash != archive_member_hash:
                raise ValueError(f"Extracted source differs from supplied archive: {info.filename}")
            files.append({"archive_member": info.filename,
                          "local_path": str(target.relative_to(papers_dir)),
                          "bytes": info.file_size, "sha256": local_hash,
                          "matches_archive_member": True})
    pdfs = [f for f in files if f["archive_member"].lower().endswith(".pdf")]
    if len(pdfs) != 20:
        raise ValueError(f"Expected twenty source PDFs, found {len(pdfs)}")
    return {"archive": {"path": str(archive_path), "bytes": archive_path.stat().st_size,
                         "sha256": sha256_file(archive_path)},
            "source_pdf_count": len(pdfs), "all_extracted_sources_match_archive": True,
            "files": files}


def evidence_pages(paper: dict) -> list[int]:
    result = list(paper.get("evidence_pdf_pages", []))
    for evidence in paper.get("page_evidence", []):
        result.append(evidence["page"])
    for evidence in paper.get("evidence", []):
        result.extend(evidence.get("pages", []))
    return sorted(set(int(page) for page in result))


def normalize_requirements(paper: dict) -> str:
    value = paper.get("inputs", paper.get("input_requirements", paper.get("input_and_label_requirements")))
    if isinstance(value, list):
        return "; ".join(value)
    if not isinstance(value, str) or not value:
        raise ValueError(f"No source input requirements for paper {paper.get('id')}")
    return value


def build(papers_dir: Path, archive_path: Path, extract_if_needed: bool = False) -> tuple[Path, Path]:
    manifest = verify_archive(archive_path, papers_dir, extract_if_needed)
    archive_root = papers_dir / "Numerai_20_Algorithm_Papers"
    index_path = archive_root / "paper_index.csv"
    with index_path.open("r", encoding="utf-8-sig", newline="") as stream:
        index_rows = [row for row in csv.DictReader(stream) if row.get("id")]
    index = {int(row["id"]): row for row in index_rows}
    if len(index_rows) != 20 or set(index) != set(range(1, 21)):
        raise ValueError("Source index must contain every ID from 1 to 20 exactly once")
    reviewed = {}
    review_hashes = {}
    for filename in REVIEW_FILES:
        path = papers_dir / filename
        content = json.loads(path.read_text(encoding="utf-8"))
        review_hashes[filename] = sha256_file(path)
        for paper in content["papers"]:
            identity = int(paper["id"])
            if identity in reviewed:
                raise ValueError(f"Duplicate paper across reviewed JSON files: {identity}")
            reviewed[identity] = (paper, filename)
    if set(reviewed) != set(index):
        raise ValueError("Reviewed paper IDs do not cover the full supplied index")
    source_hashes = {f["archive_member"]: f["sha256"] for f in manifest["files"]}
    rows = []
    for identity in range(1, 21):
        paper, review_file = reviewed[identity]
        item = index[identity]
        pages = evidence_pages(paper)
        if not pages or min(pages) < 1 or max(pages) > int(item["pages"]):
            raise ValueError(f"Invalid physical PDF evidence page for paper {identity}")
        scope, decision, implementation = IMPLEMENTED_SCOPE[identity]
        member = "Numerai_20_Algorithm_Papers/" + item["relative_path"]
        rows.append({"id": identity, "title": item["title"], "year": item["year"],
            "venue": item["venue"], "ccf_as_supplied": item["ccf"],
            "method": paper["method"], "requirements": normalize_requirements(paper),
            "source_url": item["landing"], "pdf_source_url": item["url"],
            "evidence_pdf_pages": ";".join(map(str, pages)),
            "decision": decision, "implementation_scope": scope,
            "implemented_this_round": implementation,
            "original_algorithm_and_benchmarks_reproduced": False,
            "review_recommendation": paper.get("adoption_decision", paper.get("decision", "")),
            "review_source": review_file, "local_pdf": member,
            "pdf_sha256": source_hashes[member]})
    output = papers_dir / "literature_matrix.csv"
    with output.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    manifest.update({"review_files_sha256": review_hashes,
        "literature_matrix": {"path": output.name, "rows": len(rows), "sha256": sha256_file(output)},
        "implementation_scope_definitions": {
            "application": "Library model applied to current data; no full published benchmark replication",
            "inspiration": "A named principle or evaluation control only; original architecture/objective not reproduced",
            "deferred": "Original method is not implemented in the current round"},
        "venue_labels": "Conference/year/CCF labels are from the supplied index, not independently certified by this script",
        "page_locator": "One-based physical page in supplied PDF"})
    manifest_path = papers_dir / "archive_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return output, manifest_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=ROOT / "Numerai_20_CCF_AB_Papers.zip")
    parser.add_argument("--papers-dir", type=Path, default=ROOT / "references/papers")
    parser.add_argument("--extract-if-needed", action="store_true",
                        help="Safely extract missing archive members; never replace changed existing references")
    args = parser.parse_args()
    matrix, manifest = build(args.papers_dir.resolve(), args.archive.resolve(), args.extract_if_needed)
    print(f"Built twenty-paper matrix: {matrix}")
    print(f"Verified source manifest: {manifest}")


if __name__ == "__main__":
    main()
