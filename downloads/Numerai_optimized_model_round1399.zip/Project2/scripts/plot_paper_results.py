"""Export reviewed research figures for the paper-informed annual-refit study.

All 2023+ results are reused historical development comparisons. The figures
never relabel them as an untouched test, live results, or investment returns.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODELS = ["P0_small_200k", "P1_medium_200k", "P2_medium_600k", "P3_recency_600k",
          "P4_xgboost", "P5_catboost", "P6_seed_ensemble", "P7_heterogeneous"]
PHASES = ["cv", "reused_development"]
PHASE_LABELS = {"cv": "Chronological CV", "reused_development": "Reused development"}
NAMES = {"P0_small_200k": "P0 Small", "P1_medium_200k": "P1 Medium",
         "P2_medium_600k": "P2 Medium", "P3_recency_600k": "P3 Recency",
         "P4_xgboost": "P4 XGBoost", "P5_catboost": "P5 CatBoost",
         "P6_seed_ensemble": "P6 Seed ensemble", "P7_heterogeneous": "P7 Mixed ensemble"}
COLORS = {"P0_small_200k": "#89959e", "P1_medium_200k": "#235b8e",
          "P2_medium_600k": "#397f9f", "P3_recency_600k": "#697528",
          "P4_xgboost": "#b56824", "P5_catboost": "#9e7937",
          "P6_seed_ensemble": "#a04e7c", "P7_heterogeneous": "#654c83"}
STYLES = ["-", "--", ":", "-."]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _budget_label(values: set[int]) -> str:
    def compact(number):
        return f"{number // 1000}k" if number % 1000 == 0 else f"{number:,}"
    ordered = sorted(values)
    if not ordered:
        raise ValueError("Missing actual training-row budget")
    return compact(ordered[0]) if len(ordered) == 1 else f"{compact(ordered[0])}–{compact(ordered[-1])}"


def read_sources(output: Path) -> tuple[pd.DataFrame, pd.DataFrame, dict, dict, dict]:
    metrics = pd.read_csv(output / "metrics.csv")
    perdate = pd.read_csv(output / "per_date_metrics.csv", parse_dates=["date"])
    selection = json.loads((output / "selection.json").read_text(encoding="utf-8"))
    run = json.loads((output / "run.json").read_text(encoding="utf-8"))
    training = json.loads((output / "training.json").read_text(encoding="utf-8"))["records"]
    if run.get("status") != "complete":
        raise ValueError("Figures require a completed run")
    if selection["selected_model"] not in MODELS or set(selection["candidates"]) != set(MODELS):
        raise ValueError("Selection does not match the fixed eight candidates")
    if selection.get("selection_phase") != "cv" or selection.get("development_used_for_selection") is not False:
        raise ValueError("Model selection must use CV only")
    summary = metrics.loc[metrics.metric.eq("NCORR")].copy()
    expected = {(phase, model) for phase in PHASES for model in MODELS}
    if summary.duplicated(["phase", "model"]).any():
        raise ValueError("Duplicate summary records")
    actual = set(summary[["phase", "model"]].itertuples(index=False, name=None))
    if actual != expected:
        raise ValueError("Summary matrix differs from the fixed phases/candidates")
    if set(perdate.phase.unique()) != set(PHASES):
        raise ValueError("Unexpected historical phase")
    if perdate.duplicated(["phase", "date", "model"]).any():
        raise ValueError("Duplicate per-date scores across refits")
    if not np.isfinite(summary["mean"]).all() or not np.isfinite(perdate["NCORR"]).all():
        raise ValueError("NCORR unavailable for one or more plotted records")
    scopes = {}
    for phase in PHASES:
        rows = perdate.loc[perdate.phase.eq(phase)]
        pivot = rows.pivot(index="date", columns="model", values="NCORR").sort_index()
        if set(pivot.columns) != set(MODELS) or pivot.isna().any().any():
            raise ValueError(f"{phase}: candidates have different scoring dates")
        populations = rows.pivot(index="date", columns="model", values="n_rows")
        if not populations.eq(populations.iloc[:, 0], axis=0).all().all():
            raise ValueError(f"{phase}: candidates have different populations")
        for model in MODELS:
            record = summary.loc[summary.phase.eq(phase) & summary.model.eq(model)].iloc[0]
            if int(record["n_scored_dates"]) != len(pivot):
                raise ValueError(f"{phase}/{model}: scored-date count differs")
            if not np.isclose(record["mean"], pivot[model].mean(), rtol=1e-10, atol=1e-12):
                raise ValueError(f"{phase}/{model}: mean does not reconcile")
        scopes[phase] = {"first_date": pivot.index.min().strftime("%Y-%m-%d"),
                         "last_date": pivot.index.max().strftime("%Y-%m-%d"),
                         "n_dates": len(pivot), "n_annual_refits": int(rows.fold.nunique())}
    budgets = {}
    for model in MODELS:
        budgets[model] = _budget_label({int(r["training_rows"]) for r in training if r["model"] == model})
    return summary, perdate, selection, scopes, budgets


def phase_scope(phase: str, scopes: dict) -> str:
    scope = scopes[phase]
    return (f"{PHASE_LABELS[phase]}: {scope['first_date']} to {scope['last_date']} "
            f"({scope['n_dates']} dates; {scope['n_annual_refits']} annual refits)")


def axis_style(axis):
    axis.spines[["top", "right"]].set_visible(False)
    axis.spines[["left", "bottom"]].set_color("#777777")
    axis.grid(axis="y", color="#dddddd", linewidth=.7)
    axis.set_axisbelow(True)
    axis.tick_params(colors="#333333", labelsize=10)


def plot_means(summary, selection, scopes, budgets, destination):
    fig, axes = plt.subplots(2, 1, figsize=(14, 9.6), sharey=True)
    fig.subplots_adjust(left=.085, right=.975, top=.85, bottom=.15, hspace=.53)
    selected = selection["selected_model"]
    values = summary["mean"].to_numpy()
    lower, upper = min(0., values.min()), max(0., values.max())
    span = max(upper - lower, .005)
    for phase, axis in zip(PHASES, axes):
        phase_values = [float(summary.loc[summary.phase.eq(phase) & summary.model.eq(model), "mean"].iloc[0])
                        for model in MODELS]
        bars = axis.bar(np.arange(len(MODELS)), phase_values, width=.68,
                        color=[COLORS[m] for m in MODELS], edgecolor="#333333", linewidth=.7)
        for model, bar, value in zip(MODELS, bars, phase_values):
            marker = " *" if model == selected else ""
            axis.annotate(f"{value:.4f}{marker}", (bar.get_x()+bar.get_width()/2, value),
                          textcoords="offset points", xytext=(0, 5 if value >= 0 else -5),
                          va="bottom" if value >= 0 else "top", ha="center", fontsize=10)
            if model == selected:
                bar.set_linewidth(2.0)
        labels = [f"{NAMES[m]}\n{budgets[m]} rows" for m in MODELS]
        axis.set_xticks(np.arange(len(MODELS)), labels, fontsize=10)
        axis.set_ylim(lower - .15*span, upper + .22*span)
        axis.axhline(0, color="#555555", linewidth=.9)
        axis.set_ylabel("Mean per-date NCORR", fontsize=11)
        axis.set_title(phase_scope(phase, scopes), loc="left", fontsize=11.5, pad=11)
        axis_style(axis)
    fig.suptitle("Paper-informed Numerai study: model comparison", x=.085, y=.975,
                 ha="left", fontsize=18)
    fig.text(.085, .925, "Equal weight per date. * marks the model selected using the frozen chronological CV rule.",
             ha="left", va="top", fontsize=10.5, color="#444444")
    fig.text(.085, .055, "Training-row budgets are actual per-refit samples; all candidates use the same eligible histories.\n"
             "The 2023+ period was already observed in the pilot and remains a reused development benchmark, not a new test.",
             ha="left", va="top", fontsize=10, color="#444444", linespacing=1.5)
    fig.savefig(destination, dpi=180, facecolor="white")
    plt.close(fig)


def plot_annual_heatmap(perdate, selection, scopes, budgets, destination):
    rows = perdate.assign(year=perdate.date.dt.year)
    annual = rows.groupby(["phase", "year", "model"], sort=True).NCORR.mean().unstack("model")
    columns = [("cv", year) for year in range(2019, 2023)] + [("reused_development", year) for year in range(2023, 2027)]
    if set(annual.index) != set(columns):
        raise ValueError("Annual heatmap requires the eight predeclared CV/development years")
    matrix = annual.loc[columns, MODELS].to_numpy().T
    if not np.isfinite(matrix).all():
        raise ValueError("Annual comparison has missing cells")
    limit = max(float(np.abs(matrix).max()), .001)
    cmap = LinearSegmentedColormap.from_list("signed_ncorr", ["#b56824", "#ffffff", "#235b8e"])
    fig, axis = plt.subplots(figsize=(13.6, 7.8))
    fig.subplots_adjust(left=.21, right=.91, top=.80, bottom=.21)
    image = axis.imshow(matrix, cmap=cmap, vmin=-limit, vmax=limit, aspect="auto")
    for i in range(len(MODELS)):
        for j in range(len(columns)):
            value = matrix[i, j]
            rgba = cmap((value + limit)/(2*limit))
            luminance = .2126*rgba[0] + .7152*rgba[1] + .0722*rgba[2]
            axis.text(j, i, f"{value:.4f}", ha="center", va="center",
                      fontsize=10.5, color="white" if luminance < .48 else "#222222")
    selected = selection["selected_model"]
    axis.set_yticks(np.arange(len(MODELS)),
                    [f"{NAMES[m]} ({budgets[m]})" + (" *" if m == selected else "") for m in MODELS], fontsize=10.5)
    date_counts = rows.groupby(["phase", "year"]).date.nunique()
    axis.set_xticks(np.arange(len(columns)), [f"{year}\n{date_counts.loc[(phase, year)]} dates" for phase, year in columns], fontsize=10)
    axis.tick_params(axis="both", length=0, pad=9)
    axis.set_xticks(np.arange(-.5, len(columns), 1), minor=True)
    axis.set_yticks(np.arange(-.5, len(MODELS), 1), minor=True)
    axis.grid(which="minor", color="#eeeeee", linewidth=.7)
    axis.tick_params(which="minor", length=0)
    axis.axvline(3.5, color="#333333", linewidth=1.8)
    axis.text(1.5, -.92, "Chronological CV", ha="center", va="bottom", fontsize=11.5)
    axis.text(5.5, -.92, "Reused development", ha="center", va="bottom", fontsize=11.5)
    for spine in axis.spines.values():
        spine.set_color("#777777")
    colorbar = fig.colorbar(image, ax=axis, fraction=.035, pad=.025)
    colorbar.set_label("Annual mean NCORR", fontsize=11)
    colorbar.ax.tick_params(labelsize=10)
    fig.suptitle("Paper-informed Numerai study: annual NCORR", x=.075, y=.975, ha="left", fontsize=18)
    fig.text(.075, .915, phase_scope("cv", scopes) + "\n" + phase_scope("reused_development", scopes),
             ha="left", va="top", fontsize=10.5, color="#444444", linespacing=1.5)
    fig.text(.075, .085, "Each cell is an equal-date mean within the displayed year; one common zero-centered color scale.\n"
             "* Model selected on CV. 2023+ was previously observed; these historical comparisons do not establish prospective gains.",
             ha="left", va="top", fontsize=10, color="#444444", linespacing=1.5)
    fig.savefig(destination, dpi=180, facecolor="white")
    plt.close(fig)


def plot_development_cumulative(perdate, selection, scopes, budgets, destination):
    selected = selection["selected_model"]
    chosen = list(dict.fromkeys(["P1_medium_200k", selected, "P6_seed_ensemble", "P7_heterogeneous"]))
    scores = perdate.loc[perdate.phase.eq("reused_development")].pivot(index="date", columns="model", values="NCORR").sort_index()
    fig, axis = plt.subplots(figsize=(13.6, 6.5))
    fig.subplots_adjust(left=.10, right=.97, top=.73, bottom=.23)
    for model, style in zip(chosen, STYLES):
        dates = pd.DatetimeIndex([scores.index.min()]).append(scores.index)
        cumulative = np.concatenate([[0.], scores[model].cumsum().to_numpy()])
        label = f"{NAMES[model]} ({budgets[model]})" + (" *" if model == selected else "")
        axis.plot(dates, cumulative, color=COLORS[model], linestyle=style, linewidth=1.9, label=label)
    year_first_dates = scores.groupby(scores.index.year).apply(lambda s: s.index.min())
    for date in year_first_dates.iloc[1:]:
        axis.axvline(date, color="#bbbbbb", linewidth=.7, linestyle=":", zorder=0)
    ticks = pd.DatetimeIndex([scores.index.min()] + list(year_first_dates.iloc[1:]) + [scores.index.max()]).unique()
    axis.set_xticks(ticks)
    axis.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
    axis.set_xlim(scores.index.min(), scores.index.max())
    axis.axhline(0, color="#555555", linewidth=.9)
    axis.set_ylabel("Cumulative NCORR\n(additive score, not return)", fontsize=11)
    axis_style(axis)
    fig.suptitle("Paper-informed Numerai study: reused development trajectory", x=.10, y=.975,
                 ha="left", fontsize=18)
    fig.text(.10, .905, phase_scope("reused_development", scopes) + "\n"
             "Annual refits use mature labels only; * marks the CV-selected model.",
             va="top", ha="left", fontsize=10.5, color="#444444", linespacing=1.5)
    handles, labels = axis.get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper left", bbox_to_anchor=(.095, .815),
               frameon=False, ncols=2, fontsize=10)
    fig.text(.10, .105, "All lines begin at zero. Dotted vertical guides mark annual refits. Successive 60-day labels overlap.\n"
             "This previously observed historical period is a development comparison; cumulative NCORR is not investment performance.",
             ha="left", va="top", fontsize=10, color="#444444", linespacing=1.5)
    fig.savefig(destination, dpi=180, facecolor="white")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results/paper_optimization")
    args = parser.parse_args()
    output = args.output_dir.resolve()
    summary, perdate, selection, scopes, budgets = read_sources(output)
    figures = output / "figures"
    figures.mkdir(exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "text.color": "#222222", "axes.labelcolor": "#222222"})
    plot_means(summary, selection, scopes, budgets, figures / "ncorr_model_comparison.png")
    plot_annual_heatmap(perdate, selection, scopes, budgets, figures / "annual_ncorr.png")
    plot_development_cumulative(perdate, selection, scopes, budgets, figures / "development_cumulative_ncorr.png")
    receipt = {"source_sha256": {name: sha256_file(output / name) for name in
                                 ["metrics.csv", "per_date_metrics.csv", "selection.json", "training.json", "run.json"]},
               "plot_code_sha256": sha256_file(Path(__file__)),
               "summary_means_reconciled_against_perdate": True,
               "metric": "Official NCORR; equal weight per scored date", "scope": scopes,
               "actual_training_row_budgets": budgets, "CV_selected_model": selection["selected_model"],
               "historical_reuse": "2023+ was observed previously and is not an untouched test",
               "cumulative_definition": "Additive cumulative NCORR with zero origin, not investment return",
               "files": ["ncorr_model_comparison.png", "annual_ncorr.png", "development_cumulative_ncorr.png"]}
    (figures / "source.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(f"Exported reviewed figures to {figures}")


if __name__ == "__main__":
    main()
