# Numerai v6 历史数据实验

本项目对应 DSCI-550 Project 2。当前工作是下载 Numerai Classic v6.0，建立数据质量检查及有时间隔离的离线对照实验。数据、模型与大体积预测保存在本地，原始 Word 文档保持原样。

## 2026-11-16 模型优化候选（第 1399 轮）

已在最新快照上完成四个方案的八年度对照与最终重训。CV 选出 350 特征、每成员 120 万行、种子 7/19/43 的正则化 LightGBM 集成；使用 800 棵树、学习率 0.03、L2 10，并严格保留 65 个工作日的标签成熟间隔。

2019–2022 CV 平均 NCORR 为 **0.033555**，原 60 万行集成为 **0.031625**。2023–2026-08-14 已观察开发期平均 NCORR 为 **0.027082**，本地固定 B0 为 **0.010132**，同协议 60 万行集成为 **0.026297**。相对后者均值约增加 3.0%，但 mean/std 从 1.601 降至 1.537、累计分数最大回撤从 0.057755 升至 0.069851，配对差值区间包含零；新候选尚未证明稳定优于原强化集成。截图中的 `ZEXUGAO` 未核实与本地 B0 的对应关系，+3.4% Simulated 不作为训练目标或改进证据。

90 项测试与独立复核通过；全部 372 个日期重算 CORR，每个年度一个完整日期重算 NCORR，全部模型及抽样哈希、最终 7,106 条 live 预测通过检查。已生成待提交 CSV，未替换既有 Numerai 提交。见 [优化报告](results/model_optimization_20261116_round1399/OPTIMIZATION_REPORT_ZH.md)、[本轮候选 CSV](output/optimized_live_round1399/Optimized_live_round1399.csv)、[模型交接说明](output/optimized_live_round1399/README_ZH.md)。新入口为 `scripts/run_model_optimization.py`、`scripts/generate_optimized_live.py`；后续用 `scripts/refit_optimized_model.py` 只重训冻结方案。

已基于新增的 20 篇论文包完成年度重训、三类树模型、时间权重和集成的 8 组对照。CV 选出的三种子 LightGBM 集成，在同协议历史开发区间将平均 NCORR 从 0.017685 提高至 0.026444，约提高 49.5%；该区间已被先前 pilot 观察过。29 项测试与独立结果复核通过，设计、论文映射及完整结果见 [基于论文的实验优化](PAPER_OPTIMIZATION.md)。原始轻量 pilot 的流程与结果继续保留在下文。

## 2026-11-16 每周 baseline（第 1399 轮）

已完整重新下载官网 v6.0 第 **1399** 轮五个历史数据文件，使用既定参数重新清洗、训练和评分。新增成熟日期为 **2026-08-14**，共 **7,119** 条记录；历史留出期现有 **189** 个日期、**1,275,804** 条记录，平均 CORR **0.009576**，总体标准差 **0.011736**，平均 NCORR **0.010132**。模型哈希与上轮相同，全部 **2,479,692** 条共同记录的标签及预测完全一致；这符合固定训练数据、抽样和参数下的确定性结果，不代表调参后的提升。历史结果仍是已观察过的开发证据。

已生成本轮 **7,106** 条 live 预测，全部 ticker、模型推理、独立秩变换及文件哈希校验通过。完整包解压后再次校验通过；项目现有 61 项测试及归档内 42 项 baseline 测试均通过。普通提交截止时间由 API 返回为 **2026-11-17 04:00 PST（America/Los_Angeles）**；质押截止时间为另一个字段且已过。材料已上传至 [GitHub 仓库](https://github.com/gengx-prog/DSCI550_Project2) 的 `main`，提交为 [da0f480](https://github.com/gengx-prog/DSCI550_Project2/commit/da0f4803fcd573bd4dc658a8fd0cb78a609add7a)。

**Numerai 提交更新（2026-11-16）**：按用户要求，已通过官网将本轮 CSV 上传至模型 `JACKIE_GENG`。刷新后 Dashboard 显示 **Round 1399 models submitted: 1 / 1**；提交详情记录文件 `XinchenGeng_baseline_live_round1399.csv`、提交时间 **15:05 PST**、状态 **Late（迟交）**。官网提交状态以此为准，不能因普通 `closeTime` 尚未到达就记作准时提交。Scores 页面 CORR60、MMC60、NCORR 等仍为空；公开 API 的 `scoreTime` 为 **2026-11-20 08:00 PST**，`resolveTime` 为 **2027-02-11 08:00 PST**。未进行质押或资金操作。旧 baseline 与本次模型哈希相同；旧轮次 1394/1395 已关闭，公开提交接口不支持指定补交历史轮次，因此未将旧 CSV 上传覆盖本轮。原始交接包中的“未提交”描述保留为打包时的历史状态。后续提交记录保存在 `output/numerai_submission_20261116_round1399/`。

上传材料：[本轮 CSV](output/baseline_live_round1399/XinchenGeng_baseline_live_round1399.csv)、[完整 live 交接包](output/XinchenGeng_baseline_live_round1399_handoff.zip)、[本周 baseline 归档](output/XinchenGeng_1116baseline.zip)、[PDF 报告](output/pdf/DSCI550_Baseline_20261116_Round1399.pdf)及[上传说明](output/baseline_weekly_20261116_round1399_latest/README.md)。历史指标和双重复核保存在 `results/xinchen_baseline_20261116_round1399_latest/`，完整数据快照位于 `snapshots/xinchen_20261116_round1399_latest/`。GitHub 本地上传源目录为 `tmp/github_named_baselines/` 中的 `XinchenGeng_1116baseline/` 和 `XinchenGeng_baseline_live_round1399/`，旧归档保留。

## 2026-11-07 官网最新数据 baseline 测试

已从官网 API 确认当前唯一数据版本为 v6.0、最新轮次为 **1394**，完整下载五个文件至 `snapshots/xinchen_20261107_round1394_latest/`，并在固定参数下重新清洗、训练、评分和独立复核。结果位于 `results/xinchen_baseline_20261107_round1394_latest/`。验证完成后 API 仍为第 1394 轮。

历史留出期现为 **2023-01-06 至 2026-08-07**，188 个日期、1,268,685 条记录；平均 CORR **0.009552**、总体标准差 **0.011762**、平均 NCORR **0.010133**。两个评估分区合计 **371 个日期、2,479,692 条预测**。较第 1392 轮新增 2026-08-07 一个日期、7,129 条记录；共有的 2,472,563 条目标/预测及 370 个日期的分数完全一致。原始 Parquet 哈希已变化，但清洗后训练/调参文件、训练抽样和模型哈希相同。新增一个日期不足以证明稳定提升，整个历史留出期仍含已观察的数据。

主训练及评分耗时 49.22 秒，拟合 1.09 秒，峰值进程内存约 4.32 GiB，不含下载和清洗。全部日期 CORR、所有新增/修订日期的模型预测与 NCORR、五个原始文件、源码和年度/失败时期统计均通过独立复核；10 项贡献目录测试通过。

材料：[新版 PDF](output/pdf/DSCI550_Baseline_20261107_Round1394.pdf)、[结果指标](results/xinchen_baseline_20261107_round1394_latest/metrics.csv)、[独立复核](results/xinchen_baseline_20261107_round1394_latest/freshness_validation.json)、[个人贡献说明](github_submission/XinchenGeng/README.md)。旧数据、结果及之前生成的提交材料均保留。

## 单独运行 Xinchen Geng 的部分

提案中的职责为 **Baseline & Validation**：LightGBM 基线、按时间验证、历史 CORR 评分。独立入口只训练 `B0_small_main`，不运行其他成员的模型改进或 live 提交。

### 2026-11-05 最新数据批次

已按用户补充要求从官方 API 完整重新下载第 **1392** 轮的五个 v6.0 文件，共 8.27 GB，保存到独立的 `snapshots/xinchen_20261105_latest/`。下载完成后再次确认当前轮次仍为 1392。原始验证日期已延伸至 **2026-10-30**；符合 `data_type == validation` 且 `target_jupiter_60` 非空的最新日期为 **2026-07-31**。官方训练文件与旧文件的 SHA256 完全相同，训练期仍截至 2018-12-28。旧数据、2026-10-30 结果及下方同日旧数据复现均保留。

已在新快照上重新清洗、训练、评分、独立复核并生成图表，结果保存在 `results/xinchen_baseline_20261105_latest/`。固定基线仍使用 200,000 条训练抽样、100 个 small 数值特征、seed 7 和 300 棵树；不依据验证分数调参。两个时间边界均相隔 70 个工作日。

| 历史分区 | 日期范围 | 日期数 | 记录数 | CORR 均值 | CORR 标准差 | NCORR 均值 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| tuning | 2019-04-05 至 2022-09-30 | 183 | 1,211,007 | 0.012133 | 0.011770 | 0.013674 |
| 已观察的 holdout，追加成熟日期 | 2023-01-06 至 2026-07-31 | 187 | 1,261,556 | 0.009496 | 0.011769 | 0.010091 |

本次新增 **2026-07-31** 一个成熟观测日期，共 **7,149** 条记录，该日期 CORR 为 **0.007117**，NCORR 为 **0.005182**。其余 2,465,414 条共有记录的目标、预测及全部 369 个共有日期的分数均与旧批次精确一致，模型文件哈希也一致。新增一个日期不足以判断稳定改进；整个历史留出期仍属于已观察的开发证据，不能视为新的未见测试集或 live 表现。

主训练及评分流程耗时 59.53 秒（不含 8.27 GB 下载和数据清洗），模型拟合 1.03 秒，峰值内存约 4.10 GiB。独立重算全部 **370** 个日期、**2,472,563** 条预测的 CORR，最大绝对误差为 `9.97e-17`。新增日期的 7,149 条保存模型预测误差为 0，独立 NCORR 投影误差为 `2.95e-17`；8 个年度统计行及 30 个连续负分时期也通过独立核验。29 项现有测试已通过。

最新结果：[汇总指标](results/xinchen_baseline_20261105_latest/metrics.csv)、[新增日期评分](results/xinchen_baseline_20261105_latest/new_dates_metrics.csv)、[新旧数据与预测对照](results/xinchen_baseline_20261105_latest/data_update_comparison.json)、[完整独立复核](results/xinchen_baseline_20261105_latest/validation.json)、[数据新鲜度与新增日期复核](results/xinchen_baseline_20261105_latest/freshness_validation.json)、[年度 CORR](results/xinchen_baseline_20261105_latest/annual_corr.csv) 及 [失败时期](results/xinchen_baseline_20261105_latest/failure_periods.csv)。图表见 [逐日期 CORR](results/xinchen_baseline_20261105_latest/figures/per_date_corr.png) 与 [累计 CORR](results/xinchen_baseline_20261105_latest/figures/cumulative_corr.png)。

再次复现第 1392 轮时，从项目根目录使用新的快照和结果目录；下载、准备和训练必须执行快照内脚本，保证数据来源与代码哈希的路径一致。若希望获取执行时的最新轮次，省略 `--round 1392`，并以新文件实际可用标签日期为准。

```powershell
$projectRoot = (Get-Location).Path
$snapshotRoot = Join-Path $projectRoot "snapshots/xinchen_20261105_latest_reproduction"
$resultPath = Join-Path $projectRoot "results/xinchen_baseline_20261105_latest_reproduction"
.\.venv\Scripts\python.exe scripts/refresh_xinchen_snapshot.py --snapshot $snapshotRoot --round 1392
.\.venv\Scripts\python.exe "$snapshotRoot/scripts/prepare_data.py"
.\.venv\Scripts\python.exe "$snapshotRoot/scripts/run_xinchen_baseline.py" --output $resultPath
.\.venv\Scripts\python.exe "$snapshotRoot/scripts/validate_xinchen_baseline.py" --root $snapshotRoot --output $resultPath
.\.venv\Scripts\python.exe "$snapshotRoot/scripts/plot_xinchen_baseline.py" --output $resultPath
.\.venv\Scripts\python.exe "$snapshotRoot/scripts/summarize_xinchen_baseline.py" --output $resultPath
.\.venv\Scripts\python.exe scripts/compare_xinchen_runs.py --previous results/xinchen_baseline_20261105 --current $resultPath --previous-root $projectRoot --current-root $snapshotRoot
```

### 原数据快照的独立基线命令

```powershell
.\.venv\Scripts\python.exe scripts/run_xinchen_baseline.py --output results/xinchen_baseline_20261105
.\.venv\Scripts\python.exe scripts/validate_xinchen_baseline.py --output results/xinchen_baseline_20261105
.\.venv\Scripts\python.exe scripts/plot_xinchen_baseline.py --output results/xinchen_baseline_20261105
.\.venv\Scripts\python.exe scripts/summarize_xinchen_baseline.py --output results/xinchen_baseline_20261105
```

以上命令显式指定 2026-11-05 新批次，旧结果保存在 `results/xinchen_baseline_20261030/`。训练、复核、绘图三个脚本未传 `--output` 时仍默认指向旧批次；再次训练须使用新的空目录。输出包含模型、逐股票预测、逐日期 CORR/NCORR、汇总指标、冻结协议、输入和代码哈希、资源记录及独立复核记录。基线复现官方教学示例：从全部合格训练记录中固定抽样 200,000 行，seed 7，使用 100 个 small 数值特征和 `target_jupiter_60`。主指标为提案要求的 CORR；NCORR 单独报告。训练后不根据验证结果调参或重训。

复核会独立重算所有日期的 CORR 和全部汇总指标，重建训练抽样，核对分区及文件哈希，并用一个完整历史留出日期检查保存的模型和 NCORR。该历史留出区间此前已被项目实验观察，结果属于历史复现与开发证据。再次运行请为以上四个命令传入同一个新的 `--output results/新目录名`；训练脚本拒绝覆盖已有结果。最后一个汇总命令在复核通过后生成年度 CORR 和连续负分时期。

### 2026-11-05 新批次

已按提案完成 Xinchen Geng 的基线重新训练、时间验证、评分与独立复核。批次日期采用洛杉矶时区；运行记录中的 UTC 时间为 2026-11-06。本轮沿用原始数据快照，历史留出期仍为 2023-01-06 至 2026-07-24，不能视为新增标签或新的未见测试集。

历史留出期 CORR 均值为 **0.009509**，总体标准差为 **0.011799**；NCORR 均值为 **0.010118**。调参时期的 CORR 均值为 0.012133。主流程耗时 174.25 秒，模型拟合 1.26 秒，峰值内存约 4.35 GiB。29 项现有测试通过；独立重算全部 369 个日期的 CORR，最大绝对误差为 `9.97e-17`。一个完整留出日期的 6,670 条预测与保存模型完全一致，NCORR 抽查通过。新旧批次的模型文件、全部 2,465,414 条预测及逐日期评分完全一致，符合固定数据、参数与种子的预期。

已补充提案要求的失败时期分析：历史留出期最差连续负分段为 **2025-10-10 至 2025-12-19**，11 个相邻观测日期的 CORR 均值为 -0.021842。连续负分按相邻的已观测日期定义，零分或正分会打断；分数之和不是投资收益或组合回撤。年度结果保留实际起止日期，2026 年仅覆盖至 7 月 24 日。

新批次结果：[汇总指标](results/xinchen_baseline_20261105/metrics.csv)、[逐日期评分](results/xinchen_baseline_20261105/per_date_metrics.csv)、[年度 CORR](results/xinchen_baseline_20261105/annual_corr.csv)、[失败时期](results/xinchen_baseline_20261105/failure_periods.csv)、[独立复核](results/xinchen_baseline_20261105/validation.json)、[运行记录](results/xinchen_baseline_20261105/run.json) 及 [复现与汇总检查](results/xinchen_baseline_20261105/reproduction_check.json)。来源和汇总脚本哈希保存在 [分析来源](results/xinchen_baseline_20261105/analysis_sources.json)。

图表：[逐日期 CORR](results/xinchen_baseline_20261105/figures/per_date_corr.png)、[累计 CORR](results/xinchen_baseline_20261105/figures/cumulative_corr.png)。轻量结果和复现说明同步保存在 [Xinchen Geng 提交目录](github_submission/XinchenGeng/README.md)。

### 2026-10-30 原始批次

2026-10-30 实际运行已完成，29 项现有测试全部通过。两个时间边界均间隔 70 个工作日；逐日期均值与总体标准差如下：

| 历史分区 | 日期范围 | 日期数 | CORR 均值 | CORR 标准差 | NCORR 均值 |
| --- | --- | ---: | ---: | ---: | ---: |
| tuning | 2019-04-05 至 2022-09-30 | 183 | 0.012133 | 0.011770 | 0.013674 |
| 已观察的 holdout | 2023-01-06 至 2026-07-24 | 186 | 0.009509 | 0.011799 | 0.010118 |

共为 2,465,414 条验证记录生成预测。独立重算全部 369 个日期的 CORR，最大绝对误差约为 `9.97e-17`；一个完整留出日期的 6,670 条模型预测完全一致，NCORR 也通过独立投影复核。主流程含输入哈希及评分共耗时 177.18 秒，训练本身 1.17 秒，进程峰值内存约 4.07 GiB。

完整结果见 [汇总指标](results/xinchen_baseline_20261030/metrics.csv)、[逐日期评分](results/xinchen_baseline_20261030/per_date_metrics.csv)、[复核记录](results/xinchen_baseline_20261030/validation.json) 和 [运行记录](results/xinchen_baseline_20261030/run.json)；图表见 [逐日期 CORR](results/xinchen_baseline_20261030/figures/per_date_corr.png) 与 [累计 CORR](results/xinchen_baseline_20261030/figures/cumulative_corr.png)。

## 运行

在项目根目录使用 Python 3.13。当前 `.venv` 复用了本机已安装的数据科学包；在其他机器上可创建独立环境并安装同一份依赖：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe scripts/download_data.py
.\.venv\Scripts\python.exe scripts/prepare_data.py
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe scripts/run_experiments.py
.\.venv\Scripts\python.exe scripts/plot_results.py
```

下载无需账号或 API 密钥。已存在的文件会经过格式检查和 SHA256 记录，新的下载先写 `.part`，完成后才替换正式文件。实验输出目录已存在时脚本会停止，避免覆盖已观察的结果；新实验使用 `--output results/new_run`。

## 数据与清洗

- 数据版本固定为 `v6.0`，显式使用 `target_jupiter_60`，并验证它与通用 `target` 列完全相同。辅助目标为 `target_jupiter_20`。
- 数据粒度为 `numerai_ticker` 与 `date`。缺失键、重复键、无效日期、错误类型及无穷值会使流程失败，避免静默修复影响标签。
- 仅采用元数据定义的 small 与 medium 数值特征；文本 `feature_country` 不进入数值模型。small 有 100 个数值特征，medium 有 350 个。
- 只保留正确 `data_type` 的历史记录及主目标已成熟的记录。辅助目标模型再根据自己的目标过滤。特征缺失值保留给 LightGBM 原生处理，不做基于验证集的填充或缩放。
- 新的离散特征必须在 0–4 范围内，原始 Signals 数值特征按其原本的连续值规则保留。匿名特征不额外删异常值、截尾或重新排名。
- 清洗使用分批读写，保留所有可用训练记录；模型阶段固定抽取 200,000 行，随机种子 7。

`data/raw/v6.0/manifest.json` 保存原始文件哈希。`data/processed/v6.0/cleaning_report.json` 保存检查与剔除统计，`split_manifest.json` 保存分割规则和日期，`date_counts.csv` 保存每日期记录数。

## 预先固定的实验设计

官方训练文件作为训练集。验证文件按日期拆成调参与留出测试，留出期从 2023-01-01 之后的首个可用日期开始。训练与调参之间、调参与留出之间都留出 65 个工作日的间隔，并使用严格不等号。此处工作日是 pandas `BDay` 的周一至周五定义；官方教程使用 60，当前多留 5 天。记录完整训练集的结束日期后才抽样，不根据抽样结果缩短间隔。

| 编号 | 数值特征 | 训练目标 | 用途 |
| --- | --- | --- | --- |
| B0 | small | Jupiter60 | 官方教程参数基线 |
| E1 | medium | Jupiter60 | 特征规模对照 |
| E2 | small | Jupiter20 | 目标多样性对照 |
| E3 | small | B0 与 E2 的逐日期等权排名 | 集成对照 |

LightGBM 使用 300 棵树、学习率 0.05、最大深度 5、31 个叶子、特征采样 0.1；固定种子和 12 线程。所有直接训练模型使用同一份抽样记录，辅助目标缺失时明确记录实际训练数。

主指标是官方 `numerai_tools.scoring.neutral_correlation`（NCORR），同时记录官方原始 Numerai CORR。调参集 NCORR 均值决定入选模型；先保存 `selection.json`，再读取留出集。留出集一次性评估全部预先固定的方案，用于透明比较，不据此重新选择模型。报告逐日期均值、总体标准差、非年化 mean/std、最差日期、正分比例及从零起算的累计分数最大回撤。累计相关系数不是投资收益。

本轮是轻量离线 pilot。NCORR 可在历史数据计算，但真实 live NMMC 依赖当轮 meta model；当前不将离线 benchmark contribution 冒充 NMMC。缺少 neutralizer 时默认停止，不自动改用另一项主指标。

## 输出与后续工作

实验结果位于 `results/pilot/`：`metrics.csv`、`per_date_metrics.csv`、`predictions.parquet`、`models/`、`selection.json` 和 `run.json`。`run.json` 包含依赖版本、输入哈希、随机种子、抽样键哈希、参数、时间与清洗来源记录。数据与模型不加入版本库。

后续扩展包括完整训练、all 数值特征、多个时间窗口的稳定性检查，以及 11 月 6 日后的真实 live 预测与评分记录；这些工作不能由当前历史 pilot 代替。本次流程不进行账号操作或提交预测。

## 2026 年 10 月 26 日首轮实测

5 个原始文件已下载，共约 8.24 GB；清洗后的数值建模数据约 774 MB。原始 7,047,181 行与保留 6,794,857 行、排除 252,324 行完全核对一致。没有重复股票日期键，所选数值特征没有缺失值。排除项包括 85,490 条 test 记录及两个隔离区间内的 166,834 条记录。

| 数据分区 | 行数 | 日期数 | 日期范围 |
| --- | ---: | ---: | --- |
| 训练 | 4,329,443 | 835 | 2003-01-03 至 2018-12-28 |
| 调参 | 1,211,007 | 183 | 2019-04-05 至 2022-09-30 |
| 留出 | 1,254,407 | 186 | 2023-01-06 至 2026-07-24 |

各模型实际训练 200,000 条相同抽样记录，辅助目标也没有额外缺失。以下 NCORR 均为逐日期等权均值：

| 方案 | 调参 NCORR | 留出 NCORR | 留出非年化 Sharpe |
| --- | ---: | ---: | ---: |
| B0 small Jupiter60 | 0.013674 | 0.010118 | 0.823942 |
| E1 medium Jupiter60 | 0.018829 | 0.012638 | 0.914352 |
| E2 small Jupiter20 | 0.007208 | 0.011770 | 0.862682 |
| E3 排名集成 | 0.011721 | 0.012244 | 0.899530 |

E1 根据调参集 NCORR 入选，并在固定留出期取得最高均值；它在留出期也低于自身调参期的分数。当前比较仅覆盖一种训练抽样和一个时间分割，不代表统计显著优势，也不能证明未来 live 表现。留出集现在已经评分，之后若根据这些结果修改方案，必须说明该测试集已被观察，不能继续声称其完全未用于研发。

实验阶段约 70 秒，Python 进程峰值内存约 5.11 GiB。10 项测试通过。完整精度、逐日期评分、原始 CORR 及资源记录见 [指标表](results/pilot/metrics.csv)、[逐日期指标](results/pilot/per_date_metrics.csv)、[运行记录](results/pilot/run.json) 与 [选择记录](results/pilot/selection.json)。

独立复核已重算全部汇总指标，重新构造训练抽样，并对一个完整日期的 6,191 行预测独立计算 CORR 与 NCORR；结果均与记录一致。复核范围和数值误差见 [复核记录](results/pilot/validation.json)。

![四个固定方案的调参与留出 NCORR 均值](results/pilot/figures/ncorr_comparison.png)

![按调参与留出时期分别累计的 NCORR](results/pilot/figures/cumulative_ncorr.png)

## 文档中需要同步的事实

[官方数据说明](https://docs.numer.ai/numerai-tournament/data)表明 v6 数据已于 2026-10-16 发布，2026-11-06 才开放 v6 提交。Unity 评分包含 NCORR 与 NMMC，因此提案中的 CORR 不应作为唯一的 live 对照指标。固定版本的官方参考、来源清单和原始许可保存在 `references/`，独立实验代码位于 `scripts/`。

正式作业的截止日期是 2026-12-06 交代码与幻灯片、12-07 和 12-09 展示、12-14 交最终报告。提案的展示日期及第二模型开始提交时间存在内部不一致，后续修订应以作业要求和实际实验进展为准。
