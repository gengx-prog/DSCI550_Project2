"""Paper-informed tree, recency and ensemble ablations under purged annual refits.

2023+ is a reused development benchmark, never a new untouched test set.
"""
from __future__ import annotations

import argparse
import gc
import importlib.metadata
import json
from pathlib import Path
import platform
import time
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from numerai_tools.scoring import neutral_correlation, numerai_corr
from threadpoolctl import threadpool_limits

from run_experiments import PeakMemoryMonitor, read_neutralizers, sha256_file, write_json
from paper_models import train_predict_suite
from paper_protocol import load_research_pool, make_fold_plan, split_fold
from paper_statistics import summarize, select_candidate, paired_block_bootstrap

ROOT = Path(__file__).resolve().parents[1]
MODEL_NAMES = ["P0_small_200k", "P1_medium_200k", "P2_medium_600k", "P3_recency_600k",
               "P4_xgboost", "P5_catboost", "P6_seed_ensemble", "P7_heterogeneous"]
KEYS = ["numerai_ticker", "date"]
TARGET = "target_jupiter_60"


def score_fold(predictions, neutralizer_path, fold):
    if not predictions[MODEL_NAMES + [TARGET]].notna().all().all():
        raise ValueError("Missing prediction or target")
    neutralizers, coverage = read_neutralizers(neutralizer_path, predictions)
    if neutralizers is None:
        raise FileNotFoundError("NCORR neutralizers are required")
    records = []
    for date, group in predictions.groupby("date", sort=True):
        if (group[MODEL_NAMES].nunique() < 2).any():
            raise ValueError(f"Constant prediction on {date}")
        corr = numerai_corr(group[MODEL_NAMES], group[TARGET], max_filtered_index_ratio=0)
        ncorr = neutral_correlation(group[MODEL_NAMES], neutralizers.loc[group.index],
                                    group[TARGET], max_filtered_index_ratio=0)
        for model in MODEL_NAMES:
            records.append({"phase": fold["phase"], "fold": fold["id"], "date": date,
                            "model": model, "n_rows": len(group),
                            "CORR": float(corr[model]), "NCORR": float(ncorr[model])})
    result = pd.DataFrame(records)
    if not np.isfinite(result[["CORR", "NCORR"]].to_numpy()).all():
        raise ValueError("Undefined score")
    return result, coverage


def run(args, memory):
    out = args.output.resolve()
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f"Preserving existing run: {out}; use a different --output")
    out.mkdir(parents=True, exist_ok=True)
    memory.run_started = True
    began = time.perf_counter()
    manifest = {"status": "started", "started_utc": datetime.now(timezone.utc),
        "kind": "paper_informed_development", "dataset": "v6.0", "target": TARGET,
        "seed": args.seed, "max_train_rows": args.max_train_rows, "n_jobs": args.n_jobs,
        "candidates": MODEL_NAMES, "python": platform.python_version(),
        "packages": {p: importlib.metadata.version(p) for p in
                     ["numpy", "pandas", "pyarrow", "lightgbm", "xgboost", "catboost", "numerai-tools", "scipy"]},
        "code_sha256": {p.name: sha256_file(p) for p in
                        [Path(__file__)] + [ROOT / "scripts" / f"paper_{m}.py" for m in ["models", "protocol", "statistics"]]},
        "archive_sha256": sha256_file(ROOT / "Numerai_20_CCF_AB_Papers.zip"),
        "interpretation": "2023+ has already been evaluated in pilot; all its new scores are reused development comparisons",
        "label_availability": "Each annual model trains strictly before actual evaluation first date minus 65 weekdays",
        "selection_rule": "CV equal-date mean NCORR - 0.5 * population std of annual fold mean NCORR",
        "completed_folds": []}
    write_json(out / "run.json", manifest)
    pool, feature_sets, provenance = load_research_pool(ROOT)
    plan = make_fold_plan(pool)
    if not all(f["phase"] in {"cv", "reused_development"} for f in plan):
        raise ValueError("Invalid phase identity")
    write_json(out / "plan.json", {"predeclared_at_utc": datetime.now(timezone.utc),
        "folds": plan, "models": MODEL_NAMES, "max_train_rows": args.max_train_rows,
        "seed": args.seed, "baseline_for_paired_comparison": "P1_medium_200k",
        "changes_vs_pilot": "Annual refit and expanded training history apply to every candidate; old pilot is not a matched control",
        "source_provenance": provenance})
    all_scores, all_training = [], []
    try:
        for phase in ["cv", "reused_development"]:
            phase_folds = [f for f in plan if f["phase"] == phase]
            for fold in phase_folds:
                tick = time.perf_counter()
                train, evaluation = split_fold(pool, fold)
                print(f"{fold['id']}: {len(train):,} eligible training rows; {len(evaluation):,} evaluation rows", flush=True)
                fold_dir = out / "folds" / fold["id"]
                fold_dir.mkdir(parents=True)
                predictions, training = train_predict_suite(train, evaluation, feature_sets,
                    fold_dir / "models", max_train_rows=args.max_train_rows, seed=args.seed, n_jobs=args.n_jobs)
                del train, evaluation
                predictions = predictions.reset_index(drop=True)
                if predictions.duplicated(KEYS).any():
                    raise ValueError("Duplicated prediction keys")
                scores, coverage = score_fold(predictions, ROOT / "data/raw/v6.0/validation_neutralizer.parquet", fold)
                predictions.to_parquet(fold_dir / "predictions.parquet", index=False)
                scores.to_csv(fold_dir / "per_date_metrics.csv", index=False, date_format="%Y-%m-%d")
                write_json(fold_dir / "training.json", {"fold": fold, "models": training,
                    "neutralizer": coverage, "elapsed_seconds": time.perf_counter() - tick})
                all_scores.append(scores)
                for row in training:
                    all_training.append({"fold": fold["id"], "phase": phase, **row})
                pd.concat(all_scores, ignore_index=True).to_csv(out / "per_date_metrics.csv", index=False, date_format="%Y-%m-%d")
                write_json(out / "training.json", {"records": all_training})
                manifest["completed_folds"].append(fold["id"])
                write_json(out / "run.json", manifest)
                print(f"{fold['id']} complete in {time.perf_counter() - tick:.1f}s", flush=True)
                del predictions, scores
                gc.collect()
            if phase == "cv":
                cv_scores = pd.concat(all_scores, ignore_index=True)
                selection = select_candidate(cv_scores)
                selection.update(frozen_at_utc=datetime.now(timezone.utc),
                    reused_development_scored_before_this_run_selection=False,
                    historical_benchmark_already_observed_in_prior_pilot=True)
                write_json(out / "selection.json", selection)
                print(f"CV selection frozen: {selection['selected_model']}", flush=True)
        combined = pd.concat(all_scores, ignore_index=True)
        summarize(combined).to_csv(out / "metrics.csv", index=False)
        bootstrap = paired_block_bootstrap(combined.loc[combined.phase.eq("reused_development")], selection["selected_model"])
        write_json(out / "paired_comparison.json", bootstrap)
        manifest.update(status="complete", completed_utc=datetime.now(timezone.utc),
            elapsed_seconds=time.perf_counter() - began, selected_model=selection["selected_model"],
            source_provenance=provenance, feature_counts={k: len(v) for k, v in feature_sets.items()})
        write_json(out / "run.json", manifest)
        print(f"Complete: {out}", flush=True)
    except BaseException as exc:
        manifest.update(status="failed", error=f"{type(exc).__name__}: {exc}", failed_utc=datetime.now(timezone.utc))
        write_json(out / "run.json", manifest)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "results/paper_optimization")
    parser.add_argument("--max-train-rows", type=int, default=600000)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--n-jobs", type=int, default=12)
    args = parser.parse_args()
    if args.max_train_rows < 200000 or args.n_jobs < 1:
        parser.error("The controlled matrix needs at least 200000 training rows and a positive thread count")
    monitor = PeakMemoryMonitor()
    try:
        with monitor, threadpool_limits(limits=args.n_jobs):
            run(args, monitor)
    except BaseException as exc:
        if monitor.run_started:
            path = args.output.resolve() / "run.json"
            if path.exists():
                result = json.loads(path.read_text(encoding="utf-8"))
                result.update(status="failed", error=f"{type(exc).__name__}: {exc}", failed_utc=datetime.now(timezone.utc))
                write_json(path, result)
        raise
    finally:
        if monitor.run_started:
            path = args.output.resolve() / "run.json"
            if path.exists():
                result = json.loads(path.read_text(encoding="utf-8"))
                result["memory"] = monitor.result()
                write_json(path, result)


if __name__ == "__main__":
    main()
