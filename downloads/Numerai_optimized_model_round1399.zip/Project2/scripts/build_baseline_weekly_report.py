"""Build the dated baseline progress report from archived local evidence."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    Image, PageBreak, Paragraph, SimpleDocTemplate,
    Spacer, Table, TableStyle,
)


ROOT = Path(__file__).resolve().parents[1]
BATCH = "xinchen_baseline_20261105_latest"
EVIDENCE = ROOT / "results" / BATCH
OUT = ROOT / "output" / "baseline_weekly_20261107"
PDF = ROOT / "output" / "pdf" / "DSCI550_Baseline_Weekly_Update_20261107.pdf"
TITLE = "Numerai Baseline Weekly Progress Update"
META = "DSCI 550 Project 2 | Xinchen Geng | Week ending November 7 2026"


def load_json(name):
    return json.loads((EVIDENCE / name).read_text(encoding="utf-8"))


def build():
    OUT.mkdir(parents=True, exist_ok=True)
    PDF.parent.mkdir(parents=True, exist_ok=True)
    run = load_json("run.json")
    validation = load_json("validation.json")
    freshness = load_json("freshness_validation.json")
    protocol = load_json("protocol.json")
    with (EVIDENCE / "metrics.csv").open(encoding="utf-8", newline="") as stream:
        metrics = {(r["split"], r["metric"]): r for r in csv.DictReader(stream)}
    assert validation["status"] == freshness["status"] == "passed"
    assert protocol["historical_holdout_previously_observed"] is True
    assert freshness["round"] == 1392
    assert validation["all_date_corr"]["dates"] == 370
    assert validation["all_date_corr"]["rows"] == 2472563

    summary = (
        "The fixed LightGBM baseline and chronological validation are complete for my "
        "Baseline and Validation contribution. The November 5 round 1392 snapshot produces "
        "mean historical holdout CORR of 0.009496 across 187 observation dates. This provides "
        "a reproducible reference for the team's model comparisons. The historical holdout "
        "was viewed in earlier experiments, so these results are development evidence; "
        "they do not establish performance on a fresh unseen test set or in live rounds."
    )
    completed = (
        "Reproduced the fixed baseline on the archived data, then downloaded all five "
        "complete v6.0 files for round 1392 into an isolated snapshot on November 5 "
        "(America/Los_Angeles). Repeated data preparation, training, historical scoring, "
        "and independent validation. Preserved the earlier runs, frozen protocol, input "
        "and code hashes, annual summaries, failure periods, and CORR figures."
    )
    setup = (
        "B0_small_main uses 100 small numeric features and target_jupiter_60. A fixed "
        "200,000-row sample (seed 7) is drawn from 4,329,443 eligible training rows dated "
        "2003-01-03 through 2018-12-28. LightGBM uses 300 trees, learning rate 0.05, "
        "depth 5, 31 leaves, and column sampling 0.1. No validation-based tuning, early "
        "stopping, model selection, or refitting is performed. Missing target rows are "
        "excluded; native feature NaNs are retained."
    )
    embargo = (
        "Chronological partitions use a 65-weekday embargo, with 70 weekdays between "
        "each pair of retained boundaries. Weekdays follow pandas BDay (Monday-Friday), "
        "rather than an exchange holiday calendar. CORR is the proposal's primary "
        "metric; NCORR is reported separately. Each scored date has equal weight; "
        "standard deviation uses ddof=0. The period named tuning is descriptive here "
        "and is not used to tune this fixed baseline."
    )
    refresh = (
        "The refresh adds only July 31 2026: 7,149 rows, CORR 0.007117 and NCORR "
        "0.005182. All 369 shared dates and 2,465,414 shared predictions are unchanged, "
        "as are the training sample and model hashes. Mature eligible labels end on "
        "July 31 although the raw validation file extends to October 30. One added "
        "date cannot establish stable improvement."
    )
    checks = (
        "The November 5 independent audit passed for all 370 CORR dates and 2,472,563 "
        "prediction rows (maximum CORR error 9.97e-17), including sample reconstruction, "
        "split boundaries, and source hashes. Saved-model predictions matched exactly "
        "on checked full dates; NCORR received independent full-date spot checks. "
        "The contribution's 10 cleaning and scoring tests were rerun on November 7 and passed."
    )
    runtime = (
        f"Recorded training and scoring: {run['elapsed_seconds']:.2f} seconds, including "
        f"input hashing; model fitting: {run['training']['training_seconds']:.2f} seconds; "
        f"peak process memory: {run['memory']['peak_rss_gib']:.2f} GiB. Download and data "
        "preparation are excluded. Runtime depends on hardware."
    )
    diagnostics = (
        "The worst consecutive negative-CORR sequence in the historical holdout is "
        "October 10 to December 19 2025: 11 adjacent observed dates, with mean CORR "
        "-0.021842. Mean CORR is 0.006876 in 2025 and 0.004342 in the partial 2026 "
        "period ending July 31. The late-2025 weakness is a useful stress period for "
        "future comparisons. CORR and cumulative CORR are score diagnostics, not "
        "investment returns."
    )
    next_steps = (
        "For the next update, preserve B0 and its evaluation protocol, compare candidate "
        "models on identical dates using paired score differences, and examine behavior "
        "during the late-2025 failure period. Coordinate the baseline handoff with "
        "Zexu Gao for the proposal's live-submission work. Live submission receipts "
        "and live MMC/NMMC results are not documented in this baseline evidence."
    )
    evidence = (
        "In the ZIP, start with DSCI550_Project2/XinchenGeng/README.md for pinned "
        "dependencies and the isolated-snapshot reproduction commands. This report "
        f"uses results/{BATCH}/ under that contribution: metrics.csv, "
        "per_date_metrics.csv, protocol.json, run.json, validation.json, "
        "freshness_validation.json, data_update_comparison.json, annual_corr.csv, "
        "and failure_periods.csv. The two CORR figures and lightweight data provenance "
        "are included. Raw data, trained models, and row-level prediction Parquet "
        "files must be regenerated locally using matching snapshots for a full audit."
    )

    period_rows = []
    for split, label in [("tuning", "Tuning period"), ("holdout", "Historical holdout*")]:
        corr, ncorr = metrics[(split, "CORR")], metrics[(split, "NCORR")]
        s = run["splits"][split]
        period_rows.append([
            label + "\n" + s["min_date"][:10] + " to " + s["max_date"][:10],
            str(s["dates"]), f"{s['rows']:,}",
            f"{float(corr['mean']):.6f}", f"{float(corr['std_ddof0']):.6f}",
            f"{float(ncorr['mean']):.6f}",
        ])

    sections = [
        ("Progress", summary), ("Completed this week", completed),
        ("Fixed baseline and validation", setup), ("Chronological evaluation", embargo),
        ("Data refresh", refresh), ("Verification", checks), ("Runtime", runtime),
        ("Failure periods and limits", diagnostics), ("Next update", next_steps),
        ("Evidence and reproduction", evidence),
    ]
    table_text = "\n".join(" | ".join(x.replace("\n", ": ") for x in r) for r in period_rows)
    full_text = TITLE + "\n" + META + "\n\n"
    for title, content in sections:
        full_text += title.upper() + "\n" + content + "\n\n"
        if title == "Chronological evaluation":
            full_text += (
                "Period and dates | Dates | Rows | CORR mean | CORR std | NCORR mean\n"
                + table_text + "\n* Historical holdout includes previously observed dates.\n\n"
            )
    (OUT / "Baseline_Weekly_Update_20261107.txt").write_text(full_text, encoding="utf-8")
    weekly = ROOT / "github_submission" / "XinchenGeng" / "weekly_updates"
    weekly.mkdir(parents=True, exist_ok=True)
    (weekly / "2026-11-07.txt").write_text(full_text, encoding="utf-8")

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle("ReportTitle", fontName="Helvetica-Bold", fontSize=19,
                              leading=23, textColor=colors.black, spaceAfter=7))
    styles.add(ParagraphStyle("Meta", fontName="Helvetica", fontSize=9, leading=12,
                              textColor=colors.HexColor("#4b5563"), spaceAfter=13))
    styles.add(ParagraphStyle("Section", fontName="Helvetica-Bold", fontSize=11,
                              leading=14, textColor=colors.black, spaceBefore=10,
                              spaceAfter=5, keepWithNext=True))
    styles.add(ParagraphStyle("ReportBody", fontName="Helvetica", fontSize=10,
                              leading=13.5, textColor=colors.black, spaceAfter=5))
    styles.add(ParagraphStyle("SmallNote", fontName="Helvetica", fontSize=8.2,
                              leading=11, textColor=colors.HexColor("#374151"), spaceAfter=6))
    styles.add(ParagraphStyle("Cell", fontName="Helvetica", fontSize=8.2, leading=11,
                              textColor=colors.black, alignment=TA_CENTER))
    styles.add(ParagraphStyle("CellLeft", parent=styles["Cell"], alignment=TA_LEFT))
    styles.add(ParagraphStyle("CellHeader", parent=styles["Cell"], fontName="Helvetica-Bold",
                              textColor=colors.white))

    def p(text, style="ReportBody"):
        return Paragraph(escape(text).replace("\n", "<br/>"), styles[style])

    def section(title, content, style="ReportBody"):
        return [p(title, "Section"), p(content, style)]

    story = [p(TITLE, "ReportTitle"), p(META, "Meta"), p(summary)]
    story += section("Completed this week", completed)
    story += section("Fixed baseline and validation", setup)
    story.append(p(embargo))
    headers = ["Period and date range", "Dates", "Rows", "CORR\nmean", "CORR\nstd", "NCORR\nmean"]
    data = [[p(x, "CellHeader") for x in headers]]
    data += [[p(x, "CellLeft" if i == 0 else "Cell") for i, x in enumerate(r)] for r in period_rows]
    table = Table(data, colWidths=[170, 42, 64, 75, 75, 75], hAlign="LEFT", repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#263445")),
        ("BACKGROUND", (0, 2), (-1, 2), colors.HexColor("#f2f5f8")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#d9d9d9")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.extend([Spacer(1, 6), table, Spacer(1, 5),
                  p("* The historical holdout includes previously observed dates.", "SmallNote")])
    story += section("Data refresh", refresh)
    story += section("Verification and runtime", checks + " " + runtime)
    story.append(PageBreak())
    story += [p("Historical CORR and next steps", "ReportTitle")]
    fig = EVIDENCE / "figures" / "per_date_corr.png"
    width, height = ImageReader(str(fig)).getSize()
    story += [Image(str(fig), width=516, height=516 * height / width), Spacer(1, 3)]
    story += section("Failure periods and limits", diagnostics)
    story += section("Next update", next_steps)
    story += section("Evidence and reproduction", evidence, "SmallNote")

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#4b5563"))
        canvas.drawString(48, 30, "DSCI 550 | Baseline and Validation | 2026-11-07")
        canvas.drawRightString(letter[0] - 48, 30, str(doc.page))
        canvas.restoreState()

    doc = SimpleDocTemplate(str(PDF), pagesize=letter, rightMargin=48, leftMargin=48,
                            topMargin=40, bottomMargin=46, title=TITLE, author="Xinchen Geng")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print(PDF)
    print(OUT / "Baseline_Weekly_Update_20261107.txt")


if __name__ == "__main__":
    build()
